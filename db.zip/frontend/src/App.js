import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';           // Add this import
import SplashPage from './pages/SplashPage';
import HomePage from './pages/HomePage';           // Add this import
import ProfilePage from './pages/ProfilePage';     // Add this import  
import ProjectPage from './pages/ProjectPage';     // Add this import

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (token && userData) {
      setIsAuthenticated(true);
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleLogin = (userData) => {
    setIsAuthenticated(true);
    setUser(userData);
    localStorage.setItem('token', userData.token);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  return (
    <div className="app">
      {/* Show header only when logged in */}
      {isAuthenticated && <Header user={user} onLogout={handleLogout} />}
      
      <Routes>
        <Route 
          path="/" 
          element={
            !isAuthenticated ? 
            <SplashPage onLogin={handleLogin} /> : 
            <Navigate to="/home" />
          } 
        />
        <Route 
          path="/home" 
          element={
            isAuthenticated ? 
            <HomePage user={user} /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/profile/:userId" 
          element={
            isAuthenticated ? 
            <ProfilePage user={user} /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/project/:projectId" 
          element={
            isAuthenticated ? 
            <ProjectPage user={user} /> : 
            <Navigate to="/" />
          } 
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  );
}

export default App;