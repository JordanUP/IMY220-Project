import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import SearchInput from './SearchInput';

const Header = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <header style={{
      backgroundColor: 'var(--secondary-bg)',
      borderBottom: '1px solid var(--border-color)',
      padding: 'var(--spacing-sm) 0',
      position: 'sticky',
      top: 0,
      zIndex: 100
    }}>
      <div className="container">
        <nav style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 'var(--spacing-lg)'
        }}>
          
          {/* Logo */}
          <div>
            <Link 
              to="/home" 
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--spacing-sm)',
                fontWeight: '700',
                fontSize: '1.25rem',
                color: 'var(--text-primary)',
                textDecoration: 'none'
              }}
            >
              <span style={{
                background: 'linear-gradient(135deg, var(--accent-blue), var(--accent-purple))',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                fontFamily: 'var(--font-mono)',
                fontSize: '1.5rem'
              }}>
                {'</>'}
              </span>
              <span>CodeSync</span>
            </Link>
          </div>

          {/* Search */}
          <div style={{ flex: 1, maxWidth: '400px' }}>
            <SearchInput />
          </div>

          {/* Navigation */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: 'var(--spacing-md)'
          }}>
            <Link 
              to="/home" 
              style={{
                padding: 'var(--spacing-sm) var(--spacing-md)',
                borderRadius: 'var(--radius-md)',
                color: isActive('/home') ? 'var(--text-primary)' : 'var(--text-secondary)',
                backgroundColor: isActive('/home') ? 'var(--tertiary-bg)' : 'transparent',
                textDecoration: 'none',
                fontWeight: '500',
                transition: 'all 0.2s ease'
              }}
            >
              Home
            </Link>
            
            <Link 
              to={`/profile/${user?.id || '1'}`} 
              style={{
                padding: 'var(--spacing-sm) var(--spacing-md)',
                borderRadius: 'var(--radius-md)',
                color: location.pathname.includes('/profile') ? 'var(--text-primary)' : 'var(--text-secondary)',
                backgroundColor: location.pathname.includes('/profile') ? 'var(--tertiary-bg)' : 'transparent',
                textDecoration: 'none',
                fontWeight: '500',
                transition: 'all 0.2s ease'
              }}
            >
              Profile
            </Link>
            
            {/* User Menu */}
            <div style={{ position: 'relative' }}>
              <button 
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 'var(--spacing-xs)',
                  background: 'none',
                  border: 'none',
                  color: 'var(--text-primary)',
                  fontFamily: 'inherit',
                  cursor: 'pointer',
                  padding: 'var(--spacing-xs) var(--spacing-sm)',
                  borderRadius: 'var(--radius-md)'
                }}
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                <img 
                  src={user?.avatar || '/assets/images/default-avatar.png'} 
                  alt={user?.name || 'User'}
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    border: '2px solid var(--border-color)',
                    objectFit: 'cover'
                  }}
                />
                <span>{user?.name || 'User'}</span>
                <span style={{ fontSize: '0.7rem' }}>▼</span>
              </button>
              
              {isMenuOpen && (
                <div style={{
                  position: 'absolute',
                  top: '100%',
                  right: 0,
                  backgroundColor: 'var(--tertiary-bg)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  padding: 'var(--spacing-xs) 0',
                  minWidth: '160px',
                  boxShadow: 'var(--shadow-lg)',
                  zIndex: 1000
                }}>
                  <Link 
                    to={`/profile/${user?.id || '1'}`} 
                    style={{
                      display: 'block',
                      width: '100%',
                      padding: 'var(--spacing-sm) var(--spacing-md)',
                      background: 'none',
                      border: 'none',
                      color: 'var(--text-primary)',
                      textDecoration: 'none',
                      fontFamily: 'inherit',
                      textAlign: 'left',
                      cursor: 'pointer'
                    }}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    View Profile
                  </Link>
                  <div style={{
                    height: '1px',
                    backgroundColor: 'var(--border-color)',
                    margin: 'var(--spacing-xs) 0'
                  }}></div>
                  <button 
                    onClick={handleLogout}
                    style={{
                      display: 'block',
                      width: '100%',
                      padding: 'var(--spacing-sm) var(--spacing-md)',
                      background: 'none',
                      border: 'none',
                      color: 'var(--danger-red)',
                      fontFamily: 'inherit',
                      textAlign: 'left',
                      cursor: 'pointer'
                    }}
                  >
                    Log Out
                  </button>
                </div>
              )}
            </div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;