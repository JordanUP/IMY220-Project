import React from 'react';
import { useParams } from 'react-router-dom';

const ProjectPage = ({ user }) => {
  const { projectId } = useParams();
  
  return (
    <main style={{ padding: 'var(--spacing-xl) 0', flex: 1 }}>
      <div className="container">
        <div style={{ marginBottom: 'var(--spacing-xl)' }}>
          <h1>React Portfolio Website</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Project ID: {projectId} • Version 2.1.0 • Last updated 2 days ago
          </p>
        </div>
        
        <div style={{ display: 'grid', gap: 'var(--spacing-lg)' }}>
          
          {/* Project Info */}
          <div style={{ 
            backgroundColor: 'var(--secondary-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: 'var(--radius-lg)',
            padding: 'var(--spacing-xl)'
          }}>
            <h2 style={{ marginBottom: 'var(--spacing-md)' }}>Project Details</h2>
            <p style={{ color: 'var(--text-secondary)', marginBottom: 'var(--spacing-md)' }}>
              A modern portfolio website built with React and styled-components. 
              Features responsive design, dark mode, and smooth animations.
            </p>
            
            <div style={{ display: 'flex', gap: 'var(--spacing-sm)', flexWrap: 'wrap' }}>
              {['React', 'JavaScript', 'CSS'].map(tag => (
                <span 
                  key={tag}
                  style={{
                    backgroundColor: 'var(--tertiary-bg)',
                    color: 'var(--accent-purple)',
                    padding: 'var(--spacing-xs) var(--spacing-sm)',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.75rem'
                  }}
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
          
          {/* Project Status */}
          <div style={{ 
            backgroundColor: 'var(--secondary-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: 'var(--radius-lg)',
            padding: 'var(--spacing-xl)'
          }}>
            <h2 style={{ marginBottom: 'var(--spacing-md)' }}>Project Status</h2>
            <p style={{ color: 'var(--text-secondary)', marginBottom: 'var(--spacing-md)' }}>
              This project is currently in development. Check back later for updates!
            </p>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ProjectPage;