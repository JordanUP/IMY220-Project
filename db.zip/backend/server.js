const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../dist')));
}

// Dummy test user (required by assignment)
const dummyUser = {
  id: 1,
  name: 'Test User',
  username: 'testuser',
  email: 'test@test.com',
  password: 'test1234',
  avatar: '/assets/images/default-avatar.png',
  token: 'dummy-jwt-token-12345'
};

// Login endpoint (stubbed)
app.post('/api/auth/login', (req, res) => {
  console.log('Login attempt:', req.body);
  
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required'
    });
  }

  setTimeout(() => {
    if (email === dummyUser.email && password === dummyUser.password) {
      res.json({
        success: true,
        message: 'Login successful',
        ...dummyUser
      });
    } else {
      res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }
  }, 1000);
});

// Registration endpoint (stubbed)
app.post('/api/auth/register', (req, res) => {
  console.log('Registration attempt:', req.body);
  
  const { name, username, email, password } = req.body;
  
  if (!name || !username || !email || !password) {
    return res.status(400).json({
      success: false,
      message: 'All fields are required'
    });
  }

  setTimeout(() => {
    const newUser = {
      id: 2,
      name,
      username,
      email,
      avatar: '/assets/images/default-avatar.png',
      token: `dummy-jwt-token-${Date.now()}`
    };
    
    res.status(201).json({
      success: true,
      message: 'Registration successful',
      ...newUser
    });
  }, 1500);
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Server is running',
    timestamp: new Date().toISOString()
  });
});

// Catch all for undefined API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'API endpoint not found'
  });
});

// Serve React app for all non-API routes (production)
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/index.html'));
  });
}

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
  console.log(`📋 Test login: email=test@test.com, password=test1234`);
  console.log(`🏥 Health check: http://localhost:${PORT}/api/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Process terminated');
    process.exit(0);
  });
});