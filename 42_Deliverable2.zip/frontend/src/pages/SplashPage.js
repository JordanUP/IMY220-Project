import React, { useState } from 'react';
import LoginForm from '../components/LoginForm';
import SignupForm from '../components/SignupForm';

const Splash = () => {
  const [activeForm, setActiveForm] = useState('login');

  return (
    <div>
      {/* Hero Section */}
      <section className="hero">
        <h1 className="hero-title">WHO ARE WE?</h1>
        <p className="hero-subtitle">
          Welcome to la BIBLIOTECHA, your digital space for creative projects, collaboration, and exploration. 
          Discover, upload, and edit projects in our global community.
        </p>
        <div className="features-container">
          <div className="feature-card">
            <div className="feature-icon">📤</div>
            <h3 className="feature-title">Upload</h3>
            <p className="feature-description">Share your creative projects with the community</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">✏️</div>
            <h3 className="feature-title">Edit</h3>
            <p className="feature-description">Refine and improve your projects with our tools</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🔍</div>
            <h3 className="feature-title">Explore</h3>
            <p className="feature-description">Discover amazing projects from creators worldwide</p>
          </div>
        </div>
      </section>

      {/* Auth Forms Section */}
      <div className="form-container">
        {/* Form Tabs */}
        <div className="form-tabs">
          <div 
            className={`tab ${activeForm === 'signup' ? 'active' : ''}`}
            onClick={() => setActiveForm('signup')}
          >
            Sign Up
          </div>
          <div 
            className={`tab ${activeForm === 'login' ? 'active' : ''}`}
            onClick={() => setActiveForm('login')}
          >
            Sign In
          </div>
        </div>
        
        <h2 className="form-title">Let's get started</h2>
        
        {/* Conditionally render forms */}
        {activeForm === 'signup' ? <SignupForm /> : <LoginForm />}
        
        {/* Form footer */}
        <div className="form-footer">
          <p>
            {activeForm === 'signup' 
              ? 'Already have an account? ' 
              : "Don't have an account? "
            }
            <a 
              href="#" 
              className="form-footer-link"
              onClick={(e) => {
                e.preventDefault();
                setActiveForm(activeForm === 'signup' ? 'login' : 'signup');
              }}
            >
              {activeForm === 'signup' ? 'Login' : 'Sign Up'}
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Splash;