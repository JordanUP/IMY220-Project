import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import EditProfile from '../components/EditProfile';
import ProjectList from '../components/ProjectList';
import FriendsList from '../components/FriendsList';

const ProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const getCurrentUserId = () => {
    const userId = localStorage.getItem('userId');
    return userId && userId !== 'undefined' ? userId : null;
  };
  
  const currentUserId = getCurrentUserId();
  const profileId = id || currentUserId;
  const isOwnProfile = !id || id === currentUserId;

  const fetchUser = async () => {
    try {
      if (!profileId) {
        alert('Please log in to view profiles');
        navigate('/');
        return;
      }
      
      const response = await fetch(`/api/users/${profileId}`);
      if (!response.ok) throw new Error('User not found');
      
      const data = await response.json();
      setUser(data);
    } catch (err) {
      console.error('Fetch error:', err);
      alert('Failed to load profile: ' + err.message);
      navigate('/home');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, [profileId, navigate]);

  const handleProfileUpdate = (updatedUser) => {
    setUser(updatedUser);
  };

  const handleDelete = async () => {
    if (!isOwnProfile) {
      alert('You can only delete your own profile');
      return;
    }
    
    if (window.confirm('Are you sure you want to delete your profile? This cannot be undone.')) {
      try {
        const response = await fetch(`/api/users/${profileId}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Delete failed');
        
        localStorage.clear();
        alert('Profile deleted successfully');
        navigate('/');
      } catch (err) {
        console.error('Delete error:', err);
        alert('Delete failed: ' + err.message);
      }
    }
  };

  if (loading) return <div className="profile-container"><p>Loading profile...</p></div>;
  if (!user) return <div className="profile-container"><p>Profile not found</p></div>;

  return (
    <div className="profile-container">
      {/* Profile Header */}
      <div className="profile-header">
        <div className="profile-info">
          <div className="profile-avatar">
            {user.avatar ? <img src={user.avatar} alt="Profile" style={{width: '100%', height: '100%', borderRadius: '50%'}} /> : '👤'}
          </div>
          <div className="profile-details">
            <h1>{user.name}</h1>
            <p>{user.bio || 'No bio yet'}</p>
            <p>Email: {user.email}</p>
            <p style={{fontSize: '14px', color: '#95a5a6', marginTop: '10px'}}>
              Member since: {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>

      {/* Edit Profile Section (only for own profile) */}
      {isOwnProfile && (
        <EditProfile 
          userId={profileId} 
          onProfileUpdate={handleProfileUpdate}
        />
      )}

      {/* Delete Profile Button (only for own profile) */}
      {isOwnProfile && (
        <div className="profile-header" style={{backgroundColor: '#fff5f5', border: '1px solid #fed7d7'}}>
          <h3 style={{color: '#9b2c2c', marginBottom: '10px'}}>Danger Zone</h3>
          <p style={{color: '#e53e3e', marginBottom: '15px'}}>
            Once you delete your profile, there is no going back. Please be certain.
          </p>
          <button 
            onClick={handleDelete}
            className="nav-button"
            style={{backgroundColor: '#e53e3e'}}
          >
            Delete My Profile
          </button>
        </div>
      )}

      {/* Projects Section */}
      <div className="projects-section">
        <h2 className="section-title">
          {isOwnProfile ? 'My Projects' : 'Projects'}
        </h2>
        <ProjectList userId={profileId} />
      </div>

      {/* Friends Section */}
      <div className="projects-section">
        <h2 className="section-title">
          {isOwnProfile ? 'My Friends' : 'Friends'}
        </h2>
        <FriendsList userId={profileId} />
      </div>
    </div>
  );
};

export default ProfilePage;