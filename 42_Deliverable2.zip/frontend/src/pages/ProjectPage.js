import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const ProjectPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: '',
    description: '',
    type: '',
    hashtags: ''
  });
  const [message, setMessage] = useState('');
  const [files, setFiles] = useState([]);
  
  const currentUserId = localStorage.getItem('userId');

  useEffect(() => {
    async function fetchProject() {
      try {
        if (!id) {
          setLoading(false);
          return;
        }

        const response = await fetch(`/api/projects/${id}`);
        if (!response.ok) throw new Error('Project not found');
        
        const data = await response.json();
        setProject(data);
        
        // Initialize edit form with current data
        setEditForm({
          name: data.name || '',
          description: data.description || '',
          type: data.type || '',
          hashtags: Array.isArray(data.hashtags) ? data.hashtags.join(', ') : ''
        });
      } catch (err) {
        console.error('Error fetching project:', err);
        setProject(null);
      } finally {
        setLoading(false);
      }
    }

    if (id) {
      fetchProject();
    }
  }, [id]);

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      const updates = {
        ...editForm,
        hashtags: editForm.hashtags.split(',').map(tag => tag.trim()).filter(tag => tag)
      };

      const response = await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      
      if (!response.ok) throw new Error('Update failed');
      
      const updatedProject = await response.json();
      setProject(updatedProject);
      setIsEditing(false);
      alert('Project updated successfully!');
    } catch (err) {
      console.error('Error updating project:', err);
      alert('Failed to update project: ' + err.message);
    }
  };

  const handleDelete = async () => {
    if (!project || project.owner !== currentUserId) {
      alert('You can only delete your own projects');
      return;
    }

    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      try {
        const response = await fetch(`/api/projects/${id}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Delete failed');
        
        alert('Project deleted successfully');
        navigate('/home');
      } catch (err) {
        console.error('Delete error:', err);
        alert('Delete failed: ' + err.message);
      }
    }
  };

  const handleCheckout = async () => {
    if (!currentUserId) {
      alert('Please log in to check out projects');
      navigate('/');
      return;
    }

    try {
      const response = await fetch(`/api/projects/${id}/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUserId })
      });
      
      if (!response.ok) throw new Error('Checkout failed');
      
      alert('Project checked out successfully');
      window.location.reload();
    } catch (err) {
      alert('Checkout failed: ' + err.message);
    }
  };

  const handleCheckin = async (e) => {
    e.preventDefault();
    
    if (!currentUserId) {
      alert('Please log in to check in projects');
      navigate('/');
      return;
    }

    const formData = new FormData();
    formData.append('user', currentUserId);
    formData.append('message', message);
    formData.append('version', project.version); // You might want to increment this
    files.forEach(file => formData.append('files', file));

    try {
      const response = await fetch(`/api/projects/${id}/checkin`, {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) throw new Error('Checkin failed');
      
      alert('Project checked in successfully');
      setMessage('');
      setFiles([]);
      window.location.reload();
    } catch (err) {
      alert('Checkin failed: ' + err.message);
    }
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const cancelEdit = () => {
    setIsEditing(false);
    // Reset form to original project data
    if (project) {
      setEditForm({
        name: project.name || '',
        description: project.description || '',
        type: project.type || '',
        hashtags: Array.isArray(project.hashtags) ? project.hashtags.join(', ') : ''
      });
    }
  };

  if (!id) {
    return (
      <div className="global-container">
        <h1 className="page-title">All Projects</h1>
        <p>Select a project from the home page.</p>
      </div>
    );
  }

  if (loading) return <div className="global-container"><p>Loading project...</p></div>;
  if (!project) return <div className="global-container"><p>Project not found</p></div>;

  const isOwner = project.owner === currentUserId;

  return (
    <div className="global-container">
      {/* Owner Badge */}
      {isOwner && (
        <div style={{backgroundColor: '#ebf8ff', border: '1px solid #bee3f8', color: '#3182ce', padding: '15px', borderRadius: '8px', marginBottom: '20px'}}>
          <strong>You are the owner of this project</strong>
        </div>
      )}

      {/* Edit Form or Project Display */}
      {isEditing ? (
        <div className="profile-header">
          <h2 className="section-title">Edit Project</h2>
          <form onSubmit={handleEditSubmit} style={{textAlign: 'left'}}>
            <div className="form-group">
              <label className="form-label">Project Name:</label>
              <input
                type="text"
                name="name"
                value={editForm.name}
                onChange={handleEditChange}
                className="form-input"
                required
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Description:</label>
              <textarea
                name="description"
                value={editForm.description}
                onChange={handleEditChange}
                className="form-input"
                rows="3"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Type:</label>
              <input
                type="text"
                name="type"
                value={editForm.type}
                onChange={handleEditChange}
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Hashtags (comma separated):</label>
              <input
                type="text"
                name="hashtags"
                value={editForm.hashtags}
                onChange={handleEditChange}
                className="form-input"
                placeholder="javascript, react, web"
              />
            </div>
            
            <div style={{display: 'flex', gap: '15px'}}>
              <button type="submit" className="form-button signup-button" style={{width: 'auto'}}>
                Save Changes
              </button>
              <button type="button" onClick={cancelEdit} className="form-button" style={{backgroundColor: '#95a5a6', width: 'auto'}}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Project Display */
        <div className="profile-header">
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px'}}>
            <div>
              <h1 className="page-title">{project.name}</h1>
              <p style={{color: '#95a5a6', marginTop: '10px'}}>{project.description}</p>
            </div>
            
            {/* Owner Actions */}
            {isOwner && (
              <div style={{display: 'flex', gap: '10px'}}>
                <button 
                  onClick={() => setIsEditing(true)}
                  className="nav-button"
                  style={{backgroundColor: '#f39c12'}}
                >
                  Edit Project
                </button>
                <button 
                  onClick={handleDelete}
                  className="nav-button"
                  style={{backgroundColor: '#e74c3c'}}
                >
                  Delete Project
                </button>
              </div>
            )}
          </div>
          
          <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', fontSize: '14px'}}>
            <div><strong>Type:</strong> {project.type}</div>
            <div>
              <strong>Status:</strong> 
              <span style={{
                marginLeft: '8px', 
                padding: '4px 8px', 
                borderRadius: '4px',
                backgroundColor: project.status === 'checked-out' ? '#fed7d7' : '#c6f6d5',
                color: project.status === 'checked-out' ? '#9b2c2c' : '#276749'
              }}>
                {project.status}
              </span>
            </div>
            <div><strong>Version:</strong> {project.version}</div>
            <div><strong>Hashtags:</strong> {project.hashtags?.join(', ') || 'None'}</div>
            <div><strong>Owner:</strong> {project.owner === currentUserId ? 'You' : 'Another user'}</div>
            <div><strong>Members:</strong> {project.members?.length || 0}</div>
          </div>
        </div>
      )}

      {/* Files Section */}
      <div className="projects-section">
        <h2 className="section-title">Files</h2>
        {project.files && project.files.length > 0 ? (
          <div>
            {project.files.map((file, index) => (
              <div key={index} style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px', border: '1px solid #eee', borderRadius: '4px', marginBottom: '10px'}}>
                <span style={{fontFamily: 'monospace'}}>{file}</span>
                <a 
                  href={file} 
                  download 
                  className="nav-button"
                  style={{padding: '5px 10px', fontSize: '14px'}}
                >
                  Download
                </a>
              </div>
            ))}
          </div>
        ) : (
          <p style={{color: '#95a5a6'}}>No files available</p>
        )}
      </div>

      {/* Check-in History */}
      <div className="projects-section">
        <h2 className="section-title">Check-in History</h2>
        {project.checkins && project.checkins.length > 0 ? (
          <div>
            {project.checkins.map((checkin, index) => (
              <div key={index} style={{borderLeft: '4px solid #3498db', paddingLeft: '15px', marginBottom: '20px'}}>
                <p style={{fontWeight: 'bold'}}>Version: {checkin.version}</p>
                <p style={{color: '#95a5a6'}}>{checkin.message}</p>
                <p style={{fontSize: '14px', color: '#95a5a6'}}>
                  By {checkin.user === currentUserId ? 'You' : 'User'} on {new Date(checkin.date).toLocaleDateString()}
                </p>
                {checkin.files && checkin.files.length > 0 && (
                  <div style={{marginTop: '10px'}}>
                    <p style={{fontSize: '14px', fontWeight: '500'}}>Files updated:</p>
                    <ul style={{fontSize: '14px', color: '#95a5a6'}}>
                      {checkin.files.map((file, fileIndex) => (
                        <li key={fileIndex} style={{fontFamily: 'monospace'}}>• {file}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p style={{color: '#95a5a6'}}>No check-in history</p>
        )}
      </div>

      {/* Action Buttons */}
      <div style={{display: 'flex', flexWrap: 'wrap', gap: '15px', marginBottom: '30px'}}>
        <button 
          onClick={() => navigate('/home')}
          className="nav-button"
          style={{backgroundColor: '#95a5a6'}}
        >
          Back to Home
        </button>
        
        {!isEditing && isOwner && (
          <>
            <button 
              onClick={() => setIsEditing(true)}
              className="nav-button"
              style={{backgroundColor: '#f39c12'}}
            >
              Edit Project
            </button>
            <button 
              onClick={handleDelete}
              className="nav-button"
              style={{backgroundColor: '#e74c3c'}}
            >
              Delete Project
            </button>
          </>
        )}
        
        <button 
          onClick={handleCheckout}
          disabled={project.status === 'checked-out'}
          className="nav-button"
          style={{backgroundColor: project.status === 'checked-out' ? '#cbd5e0' : '#3498db'}}
        >
          {project.status === 'checked-out' ? 'Already Checked Out' : 'Check Out Project'}
        </button>
      </div>

      {/* Check-in Form */}
      {project.status === 'checked-out' && currentUserId === project.checkedOutBy && (
        <form onSubmit={handleCheckin} className="profile-header" style={{textAlign: 'left'}}>
          <h3 className="section-title">Check In Project</h3>
          
          <div className="form-group">
            <label className="form-label">Check-in Message:</label>
            <textarea 
              value={message} 
              onChange={(e) => setMessage(e.target.value)}
              className="form-input"
              placeholder="Describe the changes you made..."
              required
              rows="3"
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Updated Files:</label>
            <input 
              type="file" 
              multiple 
              onChange={(e) => setFiles(Array.from(e.target.files))}
              className="form-input"
            />
            <p style={{fontSize: '14px', color: '#95a5a6', marginTop: '5px'}}>Select files you've updated</p>
          </div>
          
          <div style={{display: 'flex', gap: '15px'}}>
            <button 
              type="submit"
              className="form-button signup-button"
              style={{width: 'auto'}}
            >
              Check In Project
            </button>
            <button 
              type="button"
              onClick={() => {
                setMessage('');
                setFiles([]);
              }}
              className="form-button"
              style={{backgroundColor: '#95a5a6', width: 'auto'}}
            >
              Clear Form
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default ProjectPage;