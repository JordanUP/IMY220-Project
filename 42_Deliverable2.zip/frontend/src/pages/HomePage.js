import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const [projects, setProjects] = useState([]);
  const [isLocal, setIsLocal] = useState(true);
  const [loading, setLoading] = useState(true);
  
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    async function fetchProjects() {
      try {
        let url = '/api/projects';
        if (isLocal && userId) {
          url = `/api/projects?type=local&userId=${userId}`;
        }
        
        const res = await fetch(url);
        if (!res.ok) throw new Error('Failed to load projects');
        
        const data = await res.json();
        setProjects(data);
      } catch (err) {
        console.error('Project fetch error:', err);
        alert('Failed to load projects: ' + err.message);
      } finally {
        setLoading(false);
      }
    }
    
    fetchProjects();
  }, [isLocal, userId]);

  if (loading) return <div className="global-container"><p>Loading projects...</p></div>;

  return (
    <div className="global-container">
      {/* Welcome Banner */}
      <div style={{
        backgroundColor: '#ebf8ff', 
        border: '1px solid #bee3f8', 
        color: '#3182ce', 
        padding: '15px', 
        borderRadius: '8px', 
        marginBottom: '20px',
        textAlign: 'center'
      }}>
        <h2>Welcome to Your Dashboard</h2>
        <p>Explore projects from {isLocal ? 'your network' : 'the global community'}</p>
      </div>

      {/* Page Header */}
      <div className="page-header">
        <h1 className="page-title">
          {isLocal ? 'Local Feed' : 'Global Feed'}
        </h1>
        <button 
          onClick={() => setIsLocal(!isLocal)}
          className="upload-button"
        >
          Switch to {isLocal ? 'Global' : 'Local'} Feed
        </button>
      </div>

      {/* Projects Grid */}
      <div className="projects-grid-large">
        {projects.map(project => (
          <div 
            key={project._id} 
            className="project-item"
            style={{cursor: 'pointer'}}
            onClick={() => {
              console.log('Navigating to:', `/projects/${project._id}`);
              window.location.href = `/projects/${project._id}`;
            }}
          >
            <div className="project-image">
              {project.image ? (
                <img 
                  src={project.image} 
                  alt={project.name} 
                  style={{width: '100%', height: '100%', objectFit: 'cover'}}
                />
              ) : (
                'Project Image'
              )}
            </div>
            <div className="project-details">
              <h3 className="project-item-title">{project.name}</h3>
              <p className="project-description">{project.description}</p>
              
              <div style={{marginTop: '15px'}}>
                <span style={{
                  padding: '4px 8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  backgroundColor: project.status === 'checked-out' ? '#fed7d7' : '#c6f6d5',
                  color: project.status === 'checked-out' ? '#9b2c2c' : '#276749'
                }}>
                  {project.status}
                </span>
                <span style={{marginLeft: '10px', fontSize: '14px', color: '#95a5a6'}}>
                  Type: {project.type}
                </span>
              </div>
              
              <div style={{
                backgroundColor: '#3498db', 
                color: 'white', 
                textAlign: 'center', 
                padding: '8px', 
                borderRadius: '4px',
                marginTop: '15px',
                fontWeight: '500'
              }}>
                Click to View Project
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {projects.length === 0 && (
        <div className="profile-header" style={{textAlign: 'center'}}>
          <p style={{color: '#95a5a6', fontSize: '18px', marginBottom: '20px'}}>
            No projects found.
          </p>
          <p style={{color: '#7f8c8d'}}>
            {isLocal 
              ? 'Add some friends or create projects to see them here!' 
              : 'No projects in the global feed. Be the first to create one!'
            }
          </p>
          <Link 
            to="/create-project" 
            className="upload-button"
            style={{marginTop: '15px', display: 'inline-block'}}
          >
            Create Your First Project
          </Link>
        </div>
      )}

      {/* Quick Actions */}
      <div className="areas-section">
        <h2 className="section-title">Quick Actions</h2>
        <div className="areas-grid">
          <div className="area-item">
            <div className="area-image">➕</div>
            <p className="area-name">Create Project</p>
          </div>
          <div className="area-item">
            <div className="area-image">👥</div>
            <p className="area-name">Find Friends</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;