import React from "react";
import { Link } from "react-router-dom";

const ProjectPreview = ({ project }) => {
    return (
        <div className="project-card">
            <h3 className="project-name">{project.name}</h3>
            <p className="project-meta">{project.description}</p>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '15px'}}>
                <span className="project-meta">
                    Type: {project.type} | Status: {project.status}
                </span>
                <Link 
                    to={`/projects/${project._id}`}
                    className="nav-button"
                    style={{padding: '5px 10px', fontSize: '14px'}}
                >
                    View Details
                </Link>
            </div>
        </div>
    );
};

export default ProjectPreview;