import React from 'react';

const EditProject = ({ projectId }) => { // Component for editing project
  const [name, setName] = useState(''); // State for name
  // Add more states for desc, etc

  const handleSubmit = async (e) => { // Async submit
    e.preventDefault();
    try {
      const res = await fetch(`/api/projects/${projectId}`, { // Fetch PUT
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }) // Updates
      });
      if (!res.ok) throw new Error('Update failed');
      alert('Project updated');
    } catch (err) {
      alert('Update failed: ' + err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4"> // Tailwind.
      <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="New Name" /> // Input.
      <button type="submit" >Update Project</button> // Button.
    </form>
  );
};

export default EditProject;
