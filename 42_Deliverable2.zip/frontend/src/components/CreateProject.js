import React, {useState} from "react";
import { useNavigate } from "react-router-dom";

const CreateProject = () => {// Component for creating a new project
    const [name, setName] = useState(''); // State for name (req)
    const [description, setDescription] = useState(''); // State for desc
    const [hashtags, setHashtags] = useState(''); // State for hashtags (comma-separated)
    const [type, setType] = useState(''); // State for type (e.g., 'web')
    const [image, setImage] = useState(null); // State for image file
    const [files, setFiles] = useState([]); // State for files array
    const navigate = useNavigate(); // Hook for redirect.

    const handleSubmit = async (e) => { // Async submit
        e.preventDefault(); // Prevent reload
        const formData = new FormData(); // FormData for files
        formData.append('name', name); // Append fields
        formData.append('description', description);
        formData.append('hashtags', hashtags.split(',')); // Split to array
        formData.append('type', type);
        formData.append('owner', localStorage.getItem('userId')); // Owner from logged-in user
        if (image) formData.append('image', image); // Append image file
        files.forEach(file => formData.append('files', file)); // Append multiple files

        try { // Try Fetch
        const res = await fetch('/api/projects', { // Native Fetch to POST
            method: 'POST', // POST for create
            body: formData // FormData (no headers, for multipart)
        });
        if (!res.ok) throw new Error('Create failed'); // Check status
        const data = await res.json(); // Parse JSON (new project)
        alert('Project created'); // Feedback
        navigate(`/project/${data._id}`); // Redirect to new project
        } catch (err) { 
        alert('Create failed: ' + err.message); // User message
        }
};

    return (
    <div className="form-container">
        <h2 className="form-title">Create New Project</h2>
        <form onSubmit={handleSubmit}>
            <div className="form-group">
                <label className="form-label">PROJECT NAME</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} required className="form-input" />
            </div>
            <div className="form-group">
                <label className="form-label">DESCRIPTION</label>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="form-input" style={{height: '100px'}} />
            </div>
            <div className="form-group">
                <label className="form-label">HASHTAGS (comma separated)</label>
                <input type="text" value={hashtags} onChange={(e) => setHashtags(e.target.value)} className="form-input" />
            </div>
            <div className="form-group">
                <label className="form-label">TYPE</label>
                <input type="text" value={type} onChange={(e) => setType(e.target.value)} className="form-input" />
            </div>
            <div className="form-group">
                <label className="form-label">PROJECT IMAGE</label>
                <input type="file" onChange={(e) => setImage(e.target.files[0])} className="form-input" />
            </div>
            <div className="form-group">
                <label className="form-label">FILES</label>
                <input type="file" multiple onChange={(e) => setFiles(Array.from(e.target.files))} className="form-input" />
            </div>
            <button type="submit" className="form-button signup-button">Create Project</button>
        </form>
    </div>
);
};

export default CreateProject;
