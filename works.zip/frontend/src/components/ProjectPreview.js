import React from "react";
import { Link } from "react-router-dom";

const ProjectPreview = ({ project }) => {
    return (
        <article className="bg-white p-4 rounded-lg shadow mb-4">
            <h3 className="text-xl font-semibold mb-2">{project.name}</h3>
            <p className="text-gray-600 mb-3">{project.description}</p>
            <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">
                    Type: {project.type} | Status: {project.status}
                </span>
                <Link 
                    to={`/projects/${project._id}`}
                    className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                >
                    View Details
                </Link>
            </div>
        </article>
    );
};

export default ProjectPreview;