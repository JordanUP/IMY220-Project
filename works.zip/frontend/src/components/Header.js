import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const userId = localStorage.getItem('userId');
  const userName = localStorage.getItem('userName');

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <header className="bg-blue-600 text-white p-4 shadow-lg">
      <nav className="container mx-auto flex justify-between items-center">
        <Link to="/home" className="text-2xl font-bold">la BIBLIOTECHA</Link>
        
        <ul className="flex space-x-6">
          <li>
            <Link to="/home" className="hover:text-blue-200 transition-colors">
              Home
            </Link>
          </li>
          <li>
            <Link to={`/profile/${userId}`} className="hover:text-blue-200 transition-colors">
              Profile
            </Link>
          </li>
        </ul>
        
        <div className="flex items-center space-x-4">
          <span>Hello, {userName}</span>
          <button 
            onClick={handleLogout}
            className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded transition-colors"
          >
            Logout
          </button>
        </div>
      </nav>
    </header>
  );
};

export default Header;