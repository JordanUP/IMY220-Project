import React, { useState, useEffect } from 'react';
import ProjectPreview from './ProjectPreview'; // Import preview

const ProjectList = ({ userId }) => { // Component for user's projects
  const [projects, setProjects] = useState([]); // State for projects
  const [loading, setLoading] = useState(true); // Loading
  const [error, setError] = useState(null); // Error state

  useEffect(() => { // Fetch on mount
    async function fetchProjects() {
      if (!userId || userId === 'undefined') {
        console.log('No valid userId provided, skipping fetch.');
        setLoading(false);
        return;
      }

      setLoading(true);
      setError('');
      
      try {
        console.log('Fetching projects for user:', userId);
        const url = `/api/projects?type=local&userId=${userId}`;
        const res = await fetch(url);
        
        if (!res.ok) {
          throw new Error(`Failed to fetch projects: ${res.status}`);
        }
        
        const data = await res.json();
        console.log('Fetched projects:', data);
        setProjects(data);
      } catch (err) {
        console.error('Project fetch error:', err);
        setError('Failed to load projects: ' + err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchProjects(); // Call
  }, [userId]); // Dep on userId

  if (loading) return <p>Loading projects...</p>;
  if (error) return <p>{error}</p>; // Display error message

  return ( // Render.
    <section>
      {projects.map(project => ( // Map.
        <ProjectPreview key={project._id} project={project} /> // Render.
      ))}
    </section>
  );
};

export default ProjectList; // Export for Profile.