import React, { useState, useEffect } from 'react';

const FriendsList = ({ userId }) => {
  const [friends, setFriends] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchData() {
      // Don't fetch if no user ID
      if (!userId || userId === 'undefined') {
        console.log('No user ID provided, skipping friends fetch');
        setLoading(false);
        return;
      }

      setLoading(true);
      setError('');
      
      try {
        console.log('Fetching friends for user:', userId);
        
        // Fetch user data to get friends list
        const userRes = await fetch(`/api/users/${userId}`);
        if (!userRes.ok) throw new Error('Failed to fetch user data');
        
        const userData = await userRes.json();
        const friendIds = userData.friends || [];
        
        console.log('Friend IDs:', friendIds);

        // Fetch details for each friend
        const friendDetails = await Promise.all(
          friendIds.map(async (friendId) => {
            const res = await fetch(`/api/users/${friendId}`);
            return res.ok ? res.json() : null;
          })
        );
        
        // Filter out any failed fetches
        const validFriends = friendDetails.filter(friend => friend !== null);
        setFriends(validFriends);

        // Fetch all users for "add friends" section
        const allUsersRes = await fetch('/api/users');
        if (allUsersRes.ok) {
          const allUsersData = await allUsersRes.json();
          setAllUsers(allUsersData.filter(user => user._id !== userId));
        }

      } catch (err) {
        console.error('Friends fetch error:', err);
        setError('Failed to load friends: ' + err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [userId]);

  const handleAddFriend = async (friendId) => {
    try {
      const res = await fetch(`/api/users/${userId}/friend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      
      if (res.ok) {
        alert('Friend added successfully');
        // Refresh the friends list
        window.location.reload();
      } else {
        throw new Error('Failed to add friend');
      }
    } catch (err) {
      alert('Failed to add friend: ' + err.message);
    }
  };

  const handleUnfriend = async (friendId) => {
    try {
      const res = await fetch(`/api/users/${userId}/unfriend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      
      if (res.ok) {
        alert('Friend removed');
        // Refresh the friends list
        window.location.reload();
      } else {
        throw new Error('Failed to remove friend');
      }
    } catch (err) {
      alert('Failed to remove friend: ' + err.message);
    }
  };

  if (!userId || userId === 'undefined') {
    return <p className="text-gray-500">Log in to see your friends</p>;
  }

  if (loading) return <p>Loading friends...</p>;
  if (error) return <p className="text-red-500">{error}</p>;

  return (
    <div className="space-y-6">
      {/* Current Friends */}
      <div>
        <h4 className="font-semibold text-lg mb-3">Your Friends ({friends.length})</h4>
        {friends.length === 0 ? (
          <p className="text-gray-500">No friends yet. Add some below!</p>
        ) : (
          <div className="space-y-2">
            {friends.map(friend => (
              <div key={friend._id} className="flex justify-between items-center p-3 border rounded">
                <div>
                  <span className="font-medium">{friend.name}</span>
                  <p className="text-sm text-gray-600">{friend.email}</p>
                </div>
                <button 
                  onClick={() => handleUnfriend(friend._id)}
                  className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                >
                  Unfriend
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Friends */}
      <div>
        <h4 className="font-semibold text-lg mb-3">Add Friends</h4>
        <div className="space-y-2">
          {allUsers.map(user => (
            <div key={user._id} className="flex justify-between items-center p-3 border rounded">
              <div>
                <span className="font-medium">{user.name}</span>
                <p className="text-sm text-gray-600">{user.email}</p>
              </div>
              <button 
                onClick={() => handleAddFriend(user._id)}
                className="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600"
              >
                Add Friend
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FriendsList;