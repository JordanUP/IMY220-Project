import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const RouteDebugger = () => {
  const location = useLocation();
  
  useEffect(() => {
    console.log('=== ROUTE CHANGED ===');
    console.log('Pathname:', location.pathname);
    console.log('Search:', location.search);
    console.log('Hash:', location.hash);
    console.log('=====================');
  }, [location]);

  return null;
};

export default RouteDebugger;