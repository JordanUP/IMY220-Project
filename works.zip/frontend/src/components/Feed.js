import React from "react";
import ProjectPreview from "./ProjectPreview";

const Feed = ({ projects }) => ( // Component for rendering feed
  <main>
    {projects.map(project => ( // Map over fetched projects
      <ProjectPreview key={project._id} project={project} /> // Render each with key for React
    ))}
  </main>
);

export default Feed;