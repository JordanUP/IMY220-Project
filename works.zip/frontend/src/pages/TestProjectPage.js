import React from 'react';
import { useParams } from 'react-router-dom';

const TestProjectPage = () => {
  const { id } = useParams();
  
  console.log('=== TEST PROJECT PAGE ===');
  console.log('useParams():', useParams());
  console.log('ID from useParams:', id);
  console.log('Window location:', window.location.href);
  console.log('========================');

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Test Project Page</h1>
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-2">Debug Information:</h2>
        <p><strong>Project ID from useParams:</strong> {id || 'UNDEFINED'}</p>
        <p><strong>Full URL:</strong> {window.location.href}</p>
        <p><strong>Pathname:</strong> {window.location.pathname}</p>
      </div>
    </div>
  );
};

export default TestProjectPage;