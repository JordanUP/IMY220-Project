import React from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';

const DebugRoute = () => {
  const params = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const testProjectIds = [
    '68daafaccdb6315be7415371',
    '68daafaccdb6315be7415372'
  ];

  const testNavigation = (path) => {
    console.log(`Navigating to: ${path}`);
    navigate(path);
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-3xl font-bold mb-4">Route Debug Info</h1>
      
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-3">Current Route Information</h2>
        <div className="space-y-2">
          <p><strong>Current Path:</strong> <code>{location.pathname}</code></p>
          <p><strong>Route Parameters:</strong> <code>{JSON.stringify(params)}</code></p>
          <p><strong>Full URL:</strong> <code>{window.location.href}</code></p>
          <p><strong>Params ID:</strong> <code>{params.id || 'undefined'}</code></p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-3">Test Navigation</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Test /projects/:id routes:</h3>
            <div className="flex flex-wrap gap-2">
              {testProjectIds.map(id => (
                <button
                  key={id}
                  onClick={() => testNavigation(`/projects/${id}`)}
                  className="bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600"
                >
                  /projects/{id.substring(0, 8)}...
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Test /project/:id routes:</h3>
            <div className="flex flex-wrap gap-2">
              {testProjectIds.map(id => (
                <button
                  key={id}
                  onClick={() => testNavigation(`/project/${id}`)}
                  className="bg-green-500 text-white px-3 py-2 rounded hover:bg-green-600"
                >
                  /project/{id.substring(0, 8)}...
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Test invalid routes:</h3>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => testNavigation('/projects')}
                className="bg-gray-500 text-white px-3 py-2 rounded hover:bg-gray-600"
              >
                /projects (no ID)
              </button>
              <button
                onClick={() => testNavigation('/projects/invalid-id')}
                className="bg-red-500 text-white px-3 py-2 rounded hover:bg-red-600"
              >
                /projects/invalid-id
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-3">LocalStorage Check</h2>
        <div className="space-y-2">
          <p><strong>User ID:</strong> <code>{localStorage.getItem('userId') || 'Not set'}</code></p>
          <p><strong>User Name:</strong> <code>{localStorage.getItem('userName') || 'Not set'}</code></p>
        </div>
      </div>
    </div>
  );
};

export default DebugRoute;