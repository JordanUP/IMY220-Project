import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import EditProfile from '../components/EditProfile';
import ProjectList from '../components/ProjectList';
import FriendsList from '../components/FriendsList';

const ProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const getCurrentUserId = () => {
    const userId = localStorage.getItem('userId');
    return userId && userId !== 'undefined' ? userId : null;
  };
  
  const currentUserId = getCurrentUserId();
  const profileId = id || currentUserId;
  const isOwnProfile = !id || id === currentUserId;

  const fetchUser = async () => {
    try {
      if (!profileId) {
        alert('Please log in to view profiles');
        navigate('/');
        return;
      }
      
      const response = await fetch(`/api/users/${profileId}`);
      if (!response.ok) throw new Error('User not found');
      
      const data = await response.json();
      setUser(data);
    } catch (err) {
      console.error('Fetch error:', err);
      alert('Failed to load profile: ' + err.message);
      navigate('/home');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, [profileId, navigate]);

  const handleProfileUpdate = (updatedUser) => {
    setUser(updatedUser);
  };

  const handleDelete = async () => {
    if (!isOwnProfile) {
      alert('You can only delete your own profile');
      return;
    }
    
    if (window.confirm('Are you sure you want to delete your profile? This cannot be undone.')) {
      try {
        const response = await fetch(`/api/users/${profileId}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Delete failed');
        
        localStorage.clear();
        alert('Profile deleted successfully');
        navigate('/');
      } catch (err) {
        console.error('Delete error:', err);
        alert('Delete failed: ' + err.message);
      }
    }
  };

  if (loading) return <p className="text-center text-gray-500 p-4">Loading profile...</p>;
  if (!user) return <p className="text-center text-red-500 p-4">Profile not found</p>;

  return (
    <div className="container mx-auto p-4 space-y-6">
      {/* Profile Header */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex items-start space-x-6">
          {user.avatar && (
            <img 
              src={user.avatar} 
              alt="Profile" 
              className="w-24 h-24 rounded-full object-cover"
            />
          )}
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
            <p className="text-gray-600 mb-4">{user.bio || 'No bio yet'}</p>
            <p className="text-gray-500">Email: {user.email}</p>
            <p className="text-sm text-gray-400 mt-2">
              Member since: {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>

      {/* Edit Profile Section (only for own profile) */}
      {isOwnProfile && (
        <EditProfile 
          userId={profileId} 
          onProfileUpdate={handleProfileUpdate}
        />
      )}

      {/* Delete Profile Button (only for own profile) */}
      {isOwnProfile && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-red-800 mb-2">Danger Zone</h3>
          <p className="text-red-600 mb-4">
            Once you delete your profile, there is no going back. Please be certain.
          </p>
          <button 
            onClick={handleDelete}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
          >
            Delete My Profile
          </button>
        </div>
      )}

      {/* Projects Section */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">
          {isOwnProfile ? 'My Projects' : 'Projects'}
        </h2>
        <ProjectList userId={profileId} />
      </div>

      {/* Friends Section */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">
          {isOwnProfile ? 'My Friends' : 'Friends'}
        </h2>
        <FriendsList userId={profileId} />
      </div>
    </div>
  );
};

export default ProfilePage;