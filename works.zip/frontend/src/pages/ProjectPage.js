import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const ProjectPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: '',
    description: '',
    type: '',
    hashtags: ''
  });
  const [message, setMessage] = useState('');
  const [files, setFiles] = useState([]);
  
  const currentUserId = localStorage.getItem('userId');

  useEffect(() => {
    async function fetchProject() {
      try {
        if (!id) {
          setLoading(false);
          return;
        }

        const response = await fetch(`/api/projects/${id}`);
        if (!response.ok) throw new Error('Project not found');
        
        const data = await response.json();
        setProject(data);
        
        // Initialize edit form with current data
        setEditForm({
          name: data.name || '',
          description: data.description || '',
          type: data.type || '',
          hashtags: Array.isArray(data.hashtags) ? data.hashtags.join(', ') : ''
        });
      } catch (err) {
        console.error('Error fetching project:', err);
        setProject(null);
      } finally {
        setLoading(false);
      }
    }

    if (id) {
      fetchProject();
    }
  }, [id]);

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      const updates = {
        ...editForm,
        hashtags: editForm.hashtags.split(',').map(tag => tag.trim()).filter(tag => tag)
      };

      const response = await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      
      if (!response.ok) throw new Error('Update failed');
      
      const updatedProject = await response.json();
      setProject(updatedProject);
      setIsEditing(false);
      alert('Project updated successfully!');
    } catch (err) {
      console.error('Error updating project:', err);
      alert('Failed to update project: ' + err.message);
    }
  };

  const handleDelete = async () => {
    if (!project || project.owner !== currentUserId) {
      alert('You can only delete your own projects');
      return;
    }

    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      try {
        const response = await fetch(`/api/projects/${id}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Delete failed');
        
        alert('Project deleted successfully');
        navigate('/home');
      } catch (err) {
        console.error('Delete error:', err);
        alert('Delete failed: ' + err.message);
      }
    }
  };

  const handleCheckout = async () => {
    if (!currentUserId) {
      alert('Please log in to check out projects');
      navigate('/');
      return;
    }

    try {
      const response = await fetch(`/api/projects/${id}/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUserId })
      });
      
      if (!response.ok) throw new Error('Checkout failed');
      
      alert('Project checked out successfully');
      window.location.reload();
    } catch (err) {
      alert('Checkout failed: ' + err.message);
    }
  };

  const handleCheckin = async (e) => {
    e.preventDefault();
    
    if (!currentUserId) {
      alert('Please log in to check in projects');
      navigate('/');
      return;
    }

    const formData = new FormData();
    formData.append('user', currentUserId);
    formData.append('message', message);
    formData.append('version', project.version); // You might want to increment this
    files.forEach(file => formData.append('files', file));

    try {
      const response = await fetch(`/api/projects/${id}/checkin`, {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) throw new Error('Checkin failed');
      
      alert('Project checked in successfully');
      setMessage('');
      setFiles([]);
      window.location.reload();
    } catch (err) {
      alert('Checkin failed: ' + err.message);
    }
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const cancelEdit = () => {
    setIsEditing(false);
    // Reset form to original project data
    if (project) {
      setEditForm({
        name: project.name || '',
        description: project.description || '',
        type: project.type || '',
        hashtags: Array.isArray(project.hashtags) ? project.hashtags.join(', ') : ''
      });
    }
  };

  if (!id) {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold mb-6">All Projects</h1>
        <p className="text-gray-600">Select a project from the home page.</p>
      </div>
    );
  }

  if (loading) return <p className="text-center p-4">Loading project...</p>;
  if (!project) return <p className="text-center p-4 text-red-500">Project not found</p>;

  const isOwner = project.owner === currentUserId;

  return (
    <div className="container mx-auto p-4 space-y-6">
      {/* Owner Badge */}
      {isOwner && (
        <div className="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-2 rounded">
          <strong>You are the owner of this project</strong>
        </div>
      )}

      {/* Edit Form or Project Display */}
      {isEditing ? (
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold mb-4">Edit Project</h2>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Project Name:</label>
              <input
                type="text"
                name="name"
                value={editForm.name}
                onChange={handleEditChange}
                className="w-full p-2 border rounded"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Description:</label>
              <textarea
                name="description"
                value={editForm.description}
                onChange={handleEditChange}
                className="w-full p-2 border rounded"
                rows="3"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Type:</label>
              <input
                type="text"
                name="type"
                value={editForm.type}
                onChange={handleEditChange}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Hashtags (comma separated):</label>
              <input
                type="text"
                name="hashtags"
                value={editForm.hashtags}
                onChange={handleEditChange}
                className="w-full p-2 border rounded"
                placeholder="javascript, react, web"
              />
            </div>
            
            <div className="flex gap-4">
              <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                Save Changes
              </button>
              <button type="button" onClick={cancelEdit} className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                Cancel
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Project Display */
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">{project.name}</h1>
              <p className="text-gray-600">{project.description}</p>
            </div>
            
            {/* Owner Actions */}
            {isOwner && (
              <div className="flex gap-2">
                <button 
                  onClick={() => setIsEditing(true)}
                  className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
                >
                  Edit Project
                </button>
                <button 
                  onClick={handleDelete}
                  className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                >
                  Delete Project
                </button>
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div><strong>Type:</strong> {project.type}</div>
            <div>
              <strong>Status:</strong> 
              <span className={`ml-2 px-2 py-1 rounded ${
                project.status === 'checked-out' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
              }`}>
                {project.status}
              </span>
            </div>
            <div><strong>Version:</strong> {project.version}</div>
            <div><strong>Hashtags:</strong> {project.hashtags?.join(', ') || 'None'}</div>
            <div><strong>Owner:</strong> {project.owner === currentUserId ? 'You' : 'Another user'}</div>
            <div><strong>Members:</strong> {project.members?.length || 0}</div>
          </div>
        </div>
      )}

      {/* Files Section */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">Files</h2>
        {project.files && project.files.length > 0 ? (
          <ul className="space-y-2">
            {project.files.map((file, index) => (
              <li key={index} className="flex justify-between items-center p-2 border rounded">
                <span className="font-mono">{file}</span>
                <a 
                  href={file} 
                  download 
                  className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                >
                  Download
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">No files available</p>
        )}
      </div>

      {/* Check-in History */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">Check-in History</h2>
        {project.checkins && project.checkins.length > 0 ? (
          <div className="space-y-4">
            {project.checkins.map((checkin, index) => (
              <div key={index} className="border-l-4 border-blue-500 pl-4 py-2">
                <p className="font-semibold">Version: {checkin.version}</p>
                <p className="text-gray-600">{checkin.message}</p>
                <p className="text-sm text-gray-500">
                  By {checkin.user === currentUserId ? 'You' : 'User'} on {new Date(checkin.date).toLocaleDateString()}
                </p>
                {checkin.files && checkin.files.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-medium">Files updated:</p>
                    <ul className="text-sm text-gray-600">
                      {checkin.files.map((file, fileIndex) => (
                        <li key={fileIndex} className="font-mono">• {file}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No check-in history</p>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-4">
        <button 
          onClick={() => navigate('/home')}
          className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
        >
          Back to Home
        </button>
        
        {!isEditing && isOwner && (
          <>
            <button 
              onClick={() => setIsEditing(true)}
              className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
            >
              Edit Project
            </button>
            <button 
              onClick={handleDelete}
              className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
            >
              Delete Project
            </button>
          </>
        )}
        
        <button 
          onClick={handleCheckout}
          disabled={project.status === 'checked-out'}
          className={`px-4 py-2 rounded ${
            project.status === 'checked-out' 
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
              : 'bg-blue-500 text-white hover:bg-blue-600'
          }`}
        >
          {project.status === 'checked-out' ? 'Already Checked Out' : 'Check Out Project'}
        </button>
      </div>

      {/* Check-in Form */}
      {project.status === 'checked-out' && currentUserId === project.checkedOutBy && (
        <form onSubmit={handleCheckin} className="bg-white p-6 rounded-lg shadow space-y-4">
          <h3 className="text-xl font-bold">Check In Project</h3>
          
          <div>
            <label className="block text-sm font-medium mb-2">Check-in Message:</label>
            <textarea 
              value={message} 
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-2 border rounded"
              placeholder="Describe the changes you made..."
              required
              rows="3"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Updated Files:</label>
            <input 
              type="file" 
              multiple 
              onChange={(e) => setFiles(Array.from(e.target.files))}
              className="w-full p-2 border rounded"
            />
            <p className="text-sm text-gray-500 mt-1">Select files you've updated</p>
          </div>
          
          <div className="flex gap-4">
            <button 
              type="submit"
              className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            >
              Check In Project
            </button>
            <button 
              type="button"
              onClick={() => {
                setMessage('');
                setFiles([]);
              }}
              className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
            >
              Clear Form
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default ProjectPage;