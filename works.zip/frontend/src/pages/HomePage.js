import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const [projects, setProjects] = useState([]);
  const [isLocal, setIsLocal] = useState(true);
  const [loading, setLoading] = useState(true);
  
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    async function fetchProjects() {
      try {
        let url = '/api/projects';
        if (isLocal && userId) {
          url = `/api/projects?type=local&userId=${userId}`;
        }
        
        const res = await fetch(url);
        if (!res.ok) throw new Error('Failed to load projects');
        
        const data = await res.json();
        setProjects(data);
      } catch (err) {
        console.error('Project fetch error:', err);
        alert('Failed to load projects: ' + err.message);
      } finally {
        setLoading(false);
      }
    }
    
    fetchProjects();
  }, [isLocal, userId]);

  if (loading) return <p className="text-center p-4">Loading projects...</p>;

  return (
    <div className="container mx-auto p-4">
      <div className="bg-blue-100 border border-blue-400 text-blue-700 p-4 rounded-lg mb-6">
      </div>

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">
          {isLocal ? 'Local Feed' : 'Global Feed'}
        </h1>
        <button 
          onClick={() => setIsLocal(!isLocal)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Switch to {isLocal ? 'Global' : 'Local'} Feed
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(project => (
          <div 
            key={project._id} 
            className="bg-white p-4 rounded-lg shadow hover:shadow-lg transition-shadow cursor-pointer border-2 border-blue-200"
            onClick={() => {
              console.log('Navigating to:', `/projects/${project._id}`);
              window.location.href = `/projects/${project._id}`;
            }}
          >
            <h3 className="text-xl font-semibold mb-2 text-blue-800">{project.name}</h3>
            <p className="text-gray-600 mb-3">{project.description}</p>
            
            <div className="text-sm text-gray-500 mb-3">
              <span className={`px-2 py-1 rounded ${
                project.status === 'checked-out' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
              }`}>
                {project.status}
              </span>
              <span className="ml-2">Type: {project.type}</span>
            </div>
            
            <div className="mt-2 text-xs text-gray-500 text-center">
              ID: {project._id}
            </div>

            <div className="bg-blue-500 text-white text-center py-2 rounded font-semibold">
              Click to View Project
            </div>
          </div>
        ))}
      </div>

      {projects.length === 0 && (
        <p className="text-center text-gray-500 p-8">
          No projects found. {isLocal ? 'Add some friends or create projects to see them here!' : 'No projects in the global feed.'}
        </p>
      )}
    </div>
  );
};

export default HomePage;