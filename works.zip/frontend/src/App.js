import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Splash from './pages/SplashPage';
import Home from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import ProjectPage from './pages/ProjectPage';
import RouteDebugger from './components/RouteDebugger';

// Create a wrapper component that uses the location as key
const ProjectPageWithKey = () => {
  const location = useLocation();
  return <ProjectPage key={location.pathname} />;
};

const App = () => (
  <Router>
    <RouteDebugger />
    <div className="min-h-screen bg-background text-text font-sans">
      <Routes>
        <Route path="/" element={<Splash />} />
        <Route path="/home" element={<><Header /><Home /></>} />
        <Route path="/profile" element={<><Header /><ProfilePage /></>} />
        <Route path="/profile/:id" element={<><Header /><ProfilePage /></>} />
        
        {/* Project routes with forced re-render */}
        <Route path="/projects/:id" element={<><Header /><ProjectPageWithKey /></>} />
        <Route path="/projects" element={<><Header /><ProjectPage /></>} />
      </Routes>
    </div>
  </Router>
);

export default App;