const express = require('express'); // Import for app
const path = require('path'); // For serving dist folder
const multer = require('multer'); // For file uploads

const app = express(); // Create Express app
const port = 5000; // Port number
const upload = multer({ dest: 'uploads/' }); // Multer storage setup for file uploads (folder for files)

const connectDB = require('./dbconnect'); // Database connection to connect on first call to any db function

app.use(express.json());  // Parses JSON bodies – missing this causes req.body undefined -> crash

app.use('/api', require('./routes/api')); // API routes, mounts routes at /api

// Serve frontend build in production/Docker
app.use(express.static(path.join(__dirname, '../dist')));

// Handle client-side routing - return index.html for all non-API routes
app.get('*', (req, res) => {
  // Don't handle API routes
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found' });
  }
  
  // For all other routes, serve the React app
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(port, '0.0.0.0', () => console.log(`Server running on port ${port}`));

app.use((err, req, res, next) => {// Global error handler
  console.error('Global error:', err.stack);  // Log full stack
  res.status(500).json({ error: 'Internal server error', message: err.message });
});

app.use((req, res) => { // 404 handler
  res.status(404).json({ error: 'Not found' });
});