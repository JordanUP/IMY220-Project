const { MongoClient } = require('mongodb');

let dbPromise = null;  // Cache promise to connect once

function connectDB() {//function to connect to MongoDB database asynchronously
  if (!dbPromise) {//if not already connected, establish connection to the database
    dbPromise = MongoClient.connect('mongodb+srv://db_user:strongpass@versioncontrol.x8gebti.mongodb.net/?retryWrites=true&w=majority&appName=versioncontrol')
      .then(client => {
        const db = client.db('versioncontrol');//specify the database name
        console.log('MongoDB connected');//log successful connection to confirm
        return db;//return the database object for further operations
      })
      .catch(err => {
        console.error('MongoDB connection error:', err);//log any connection errors for debugging
        throw err;  // Re-throw for handling
      });
  }
  return dbPromise;//return the promise to allow further operations once connected (resolves to the db object on subsequent calls, meaning it won't reconnect)
}

module.exports = connectDB;//export the connectDB function for use in db.js