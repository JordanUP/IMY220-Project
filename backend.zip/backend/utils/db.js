const connectDB = require('../dbconnect');  // Import connection func. to get DB instance
const { ObjectId } = require('mongodb');  //  For ID conversion in queries

// User functions:

// User document structure: { name: String (req), email: String (req, unique manual check), password: String (req), bio: String, avatar: String, friends: [ObjectId], projects: [ObjectId], createdAt: Date }
async function createUser(data) {  //  Async create user (for signup)
  const db = await connectDB();  //  Get DB (connects if needed)
  if (!data.name || !data.email || !data.password) throw new Error('Missing required user fields');  //  Manual validation
  const exists = await db.collection('users').findOne({ email: data.email });  //  Check for existing email manually
  if (exists) throw new Error('Email already in use');  //  If exists, error
  data.createdAt = new Date();  //  Default timestamp
  data.friends = [];  //  Default empty array for friends relationship
  data.projects = [];  //  Default empty array for projects relationship
  const result = await db.collection('users').insertOne(data);  //  Insert document into 'users' collection
  return { ...data, _id: result.insertedId };  //  Return with generated _id
}

async function getUsers() {  //  Fetch all users (for feeds/search)
  const db = await connectDB();  //  Get DB
  return await db.collection('users').find({}).toArray();  //  Find all docs, convert cursor to array (JSON-ready)
}

async function getUserById(id) {  //  Fetch single user by ID (for profile view)
  const db = await connectDB();
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  return await db.collection('users').findOne({ _id: objectId });  //  Find one doc by _id
}

async function getUserByEmail(email) {  //  Fetch single user by email (for login)
  const db = await connectDB();
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  return await db.collection('users').findOne({ email, password });  //  Find one doc by email using simple query
}

async function updateUser(id, updates) {  //  Update user fields (for profile edit)
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  const result = await db.collection('users').updateOne({ _id: objectId }, { $set: updates });  //  Update with $set to only change provided fields and leave others intact
  if (result.modifiedCount === 0) throw new Error('User not found or No changes made');  //  Check if updated (error handling)
  return { message: 'User updated' };  //  Success response
}

async function deleteUser(id) {  //  Delete user for own profile removal
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert ID
  const result = await db.collection('users').deleteOne({ _id: objectId });  //  Delete one by _id
  if (result.deletedCount === 0) throw new Error('User not found');  //  Check
  return { message: 'User deleted' };  //  Success
}

async function addFriend(userId, friendId) {  //  Add to friends array
  const db = await connectDB();  //  Get DB
  const userObjectId = new ObjectId(userId);  //  Convert
  const friendObjectId = new ObjectId(friendId);  //  Convert
  const result = await db.collection('users').updateOne({ _id: userObjectId }, { $addToSet: { friends: friendObjectId } });  //  $addToSet adds if not exists (avoids duplicates)
  return { message: 'Friend added' };  //  Success
}

async function removeFriend(userId, friendId) {  //  Remove from friends (unfriend)
  const db = await connectDB();  //  Get DB
  const userObjectId = new ObjectId(userId);  //  Convert
  const friendObjectId = new ObjectId(friendId);  //  Convert
  const result = await db.collection('users').updateOne({ _id: userObjectId }, { $pull: { friends: friendObjectId } });  //  $pull removes matching value
  return { message: 'Friend removed' };  //  Success
}

// Project functions:

// Project document structure: { name: String (req), description: String, image: String, type: String, hashtags: [String], owner: ObjectId (req), members: [ObjectId], checkins: [{ user: ObjectId, message: String, files: [String], version: String, date: Date }], status: String, checkedOutBy: ObjectId, createdAt: Date, version: String }
async function createProject(data) {  //  Create project
  const db = await connectDB();  //  Get DB
  if (!data.name || !data.owner) throw new Error('Missing required project fields');  //  Validation
  data.owner = new ObjectId(data.owner);  //  Convert ID 
  data.members = data.members ? data.members.map(id => new ObjectId(id)) : [];  //  Convert array of IDs if provided
  data.checkins = [];  //  Default empty array for check-ins
  data.createdAt = new Date();  //  Default timestamp
  data.version = '1.0';  //  Default version
  data.status = 'checked-in';  //  Default status 
  data.checkedOutBy = null;  //  Default null for checkedOutBy
  const result = await db.collection('projects').insertOne(data);  //  Insert document
  return { ...data, _id: result.insertedId };  //  Return the new project with _id
}

async function getProjects() {  //  Fetch all projects
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  return await db.collection('projects').find({}).toArray();  //  Find all docs, convert cursor to array
}

async function getProjectById(id) {  //  Fetch single project by ID
  const db = await connectDB();
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  return await db.collection('projects').findOne({ _id: objectId });  //  Find one doc by _id
}

async function updateProject(id, updates) {  //  Edit project
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert
  const result = await db.collection('projects').updateOne({ _id: objectId }, { $set: updates });  //  Update
  if (result.modifiedCount === 0) throw new Error('Project not found or not modified');  //  Check
  return { message: 'Project updated' };  //  Success
}

async function deleteProject(id) {  //  Delete project
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert
  const result = await db.collection('projects').deleteOne({ _id: objectId });  //  Delete
  if (result.deletedCount === 0) throw new Error('Project not found');  //  Check
  return { message: 'Project deleted' };  //  Success
}

async function checkoutProject(id, userId) {  //  Checkout (set status, checkedOutBy)
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert project ID
  const userObjectId = new ObjectId(userId);  //  Convert user ID
  const result = await db.collection('projects').updateOne({ _id: objectId }, { $set: { status: 'checked-out', checkedOutBy: userObjectId } });  //  Update
  if (result.modifiedCount === 0) throw new Error('Project not found');  //  Check
  return { message: 'Project checked out' };  //  Success
}

async function addCheckin(id, checkinData) {  //  Add check-in (push to array)
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert
  checkinData.user = new ObjectId(checkinData.user);  //  Convert user ID
  checkinData.date = new Date();  //  Default date
  const result = await db.collection('projects').updateOne({ _id: objectId }, { $push: { checkins: checkinData }, $set: { status: 'checked-in', checkedOutBy: null } });  //  Push check-in, set status back to checked-in
  if (result.modifiedCount === 0) throw new Error('Project not found');  //  Check
  return { message: 'Check-in added' };  //  Success
}

async function search(query) {  //  Search users/projects (multi-field $regex)
  const db = await connectDB();  //  Get DB
  const regex = new RegExp(query, 'i');  //  Case-insensitive regex
  const users = await db.collection('users').find({ $or: [{ name: regex }, { email: regex }] }).toArray();  //  Search users by name/email
  const projects = await db.collection('projects').find({ $or: [{ name: regex }, { type: regex }, { hashtags: regex }, { 'checkins.message': regex }] }).toArray();  //  Search projects by name/type/hashtags/check-in message
  return { users, projects };  //  Return combined results for frontend
}

async function getLocalProjects(userId) {  //  Fetch all projects for local user
  const db = await connectDB();
  const objectId = new ObjectId(userId); // Convert user ID
  const user = await db.collection('users').findOne({ _id: objectId }, { projection: { friends: 1, projects: 1 } }); // Get user's friends/projects.
  const friendIds = user.friends || []; // Get friends or empty array.
  const projectIds = user.projects || []; // Get user's own projects or empty array.
  const allIds = [...friendIds, objectId]; // Include own + friends.
  return await db.collection('projects').find({ $or: [{ owner: { $in: allIds } }, { members: { $in: allIds } }, { _id: { $in: projectIds } }] }).toArray(); // Find projects owned/membered by user/friends.
}

module.exports = { createUser, getUsers, getUserById, getUserByEmail, updateUser, deleteUser, addFriend, removeFriend, createProject, getProjects, getProjectById, updateProject, deleteProject, checkoutProject, addCheckin, search, getLocalProjects };  //  Export all functions for api.js (Full CRUD)