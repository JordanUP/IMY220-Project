import React, { useState } from 'react';

const SearchInput = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('projects');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Searching for:', searchTerm, 'Type:', searchType);
    // TODO: Implement search functionality in future deliverables
  };

  return (
    <form onSubmit={handleSubmit} style={{ width: '100%' }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'var(--primary-bg)',
        border: '1px solid var(--border-color)',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        transition: 'all 0.2s ease'
      }}>
        
        <select 
          value={searchType} 
          onChange={(e) => setSearchType(e.target.value)}
          style={{
            backgroundColor: 'var(--tertiary-bg)',
            border: 'none',
            color: 'var(--text-secondary)',
            padding: 'var(--spacing-sm)',
            fontFamily: 'inherit',
            fontSize: '0.875rem',
            cursor: 'pointer',
            minWidth: '80px'
          }}
        >
          <option value="projects">Projects</option>
          <option value="users">Users</option>
          <option value="hashtags">Tags</option>
        </select>
        
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={`Search ${searchType}...`}
          style={{
            flex: 1,
            background: 'none',
            border: 'none',
            color: 'var(--text-primary)',
            padding: 'var(--spacing-sm) var(--spacing-md)',
            fontFamily: 'inherit',
            fontSize: '0.875rem'
          }}
        />
        
        <button 
          type="submit" 
          style={{
            background: 'none',
            border: 'none',
            color: 'var(--text-secondary)',
            padding: 'var(--spacing-sm)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center'
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/>
            <path d="M21 21l-4.35-4.35"/>
          </svg>
        </button>
      </div>
    </form>
  );
};

export default SearchInput;