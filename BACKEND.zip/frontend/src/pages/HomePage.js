import React from 'react';

const HomePage = ({ user }) => {
  return (
    <main style={{ padding: 'var(--spacing-xl) 0', flex: 1 }}>
      <div className="container">
        <div style={{ marginBottom: 'var(--spacing-xl)' }}>
          <h1>Welcome back, {user?.name || 'Developer'}!</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Stay up to date with your projects and team activity
          </p>
        </div>
        
        <div style={{ 
          backgroundColor: 'var(--secondary-bg)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-lg)',
          padding: 'var(--spacing-xl)',
          textAlign: 'center'
        }}>
          <h2>Activity Feed Coming Soon</h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            This will show your project activity and updates from your team.
          </p>
        </div>
      </div>
    </main>
  );
};

export default HomePage;