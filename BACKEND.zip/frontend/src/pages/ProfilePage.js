import React from 'react';
import { useParams } from 'react-router-dom';

const ProfilePage = ({ user }) => {
  const { userId } = useParams();
  
  return (
    <main style={{ padding: 'var(--spacing-xl) 0', flex: 1 }}>
      <div className="container">
        <div style={{ marginBottom: 'var(--spacing-xl)' }}>
          <h1>Profile Page</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Viewing profile for user ID: {userId}
          </p>
        </div>
        
        <div style={{ 
          backgroundColor: 'var(--secondary-bg)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-lg)',
          padding: 'var(--spacing-xl)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-md)', marginBottom: 'var(--spacing-lg)' }}>
            <img 
              src={user?.avatar || '/assets/images/default-avatar.png'}
              alt="Profile"
              style={{
                width: '80px',
                height: '80px',
                borderRadius: '50%',
                border: '3px solid var(--border-color)',
                objectFit: 'cover'
              }}
            />
            <div>
              <h2>{user?.name || 'User Name'}</h2>
              <p style={{ color: 'var(--text-secondary)' }}>@{user?.username || 'username'}</p>
              <p style={{ color: 'var(--text-secondary)' }}>{user?.email || 'email@example.com'}</p>
            </div>
          </div>
          
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', 
            gap: 'var(--spacing-md)',
            textAlign: 'center'
          }}>
            <div>
              <div style={{ fontSize: '1.5rem', fontWeight: '600', color: 'var(--accent-blue)' }}>12</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Projects</div>
            </div>
            <div>
              <div style={{ fontSize: '1.5rem', fontWeight: '600', color: 'var(--accent-green)' }}>48</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Commits</div>
            </div>
            <div>
              <div style={{ fontSize: '1.5rem', fontWeight: '600', color: 'var(--accent-purple)' }}>23</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Friends</div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ProfilePage;