import React, { useState } from 'react';
import LoginForm from '../components/LoginForm';
import SignUpForm from '../components/SignUpForm';

const SplashPage = ({ onLogin }) => {
  const [activeForm, setActiveForm] = useState('login');

  return (
    <main style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, var(--primary-bg) 0%, var(--secondary-bg) 100%)',
      display: 'flex',
      alignItems: 'center',
      padding: 'var(--spacing-xl) 0'
    }}>
      <div className="container">
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 400px',
          gap: 'var(--spacing-2xl)',
          alignItems: 'center',
          minHeight: '80vh'
        }}>
          
          {/* Left side - Branding */}
          <div>
            <h1 style={{
              fontSize: '3.5rem',
              fontWeight: '700',
              marginBottom: 'var(--spacing-md)',
              display: 'flex',
              alignItems: 'center',
              gap: 'var(--spacing-md)'
            }}>
              <span style={{
                background: 'linear-gradient(135deg, var(--accent-blue), var(--accent-purple))',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                fontFamily: 'var(--font-mono)',
                fontSize: '4rem'
              }}>
                {'</>'}
              </span>
              CodeSync
            </h1>
            
            <p style={{
              fontSize: '1.5rem',
              color: 'var(--accent-blue)',
              marginBottom: 'var(--spacing-lg)',
              fontFamily: 'var(--font-mono)'
            }}>
              Collaborate. Version. Deploy.
            </p>
            
            <p style={{
              fontSize: '1.125rem',
              color: 'var(--text-secondary)',
              lineHeight: '1.7',
              maxWidth: '500px',
              marginBottom: 'var(--spacing-2xl)'
            }}>
              The modern version control platform built for developers who value 
              simplicity and powerful collaboration tools. Manage your projects, 
              track changes, and work seamlessly with your team.
            </p>

            {/* Features */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-lg)' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--spacing-md)' }}>
                <div style={{ fontSize: '2rem' }}>🚀</div>
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-primary)', marginBottom: 'var(--spacing-xs)' }}>
                    Fast & Reliable
                  </h3>
                  <p style={{ color: 'var(--text-secondary)', margin: 0 }}>
                    Lightning-fast project synchronization and deployment
                  </p>
                </div>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--spacing-md)' }}>
                <div style={{ fontSize: '2rem' }}>👥</div>
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-primary)', marginBottom: 'var(--spacing-xs)' }}>
                    Team Collaboration
                  </h3>
                  <p style={{ color: 'var(--text-secondary)', margin: 0 }}>
                    Real-time collaboration with built-in project management
                  </p>
                </div>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--spacing-md)' }}>
                <div style={{ fontSize: '2rem' }}>🔒</div>
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-primary)', marginBottom: 'var(--spacing-xs)' }}>
                    Secure & Private
                  </h3>
                  <p style={{ color: 'var(--text-secondary)', margin: 0 }}>
                    Enterprise-grade security for your valuable code
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right side - Forms */}
          <div style={{ position: 'sticky', top: 'var(--spacing-xl)' }}>
            <div style={{
              backgroundColor: 'var(--secondary-bg)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-lg)',
              overflow: 'hidden',
              boxShadow: 'var(--shadow-lg)'
            }}>
              <div style={{
                display: 'flex',
                backgroundColor: 'var(--tertiary-bg)'
              }}>
                <button 
                  style={{
                    flex: 1,
                    padding: 'var(--spacing-md)',
                    background: activeForm === 'login' ? 'var(--secondary-bg)' : 'none',
                    border: 'none',
                    color: activeForm === 'login' ? 'var(--text-primary)' : 'var(--text-secondary)',
                    fontFamily: 'inherit',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}
                  onClick={() => setActiveForm('login')}
                >
                  Log In
                </button>
                <button 
                  style={{
                    flex: 1,
                    padding: 'var(--spacing-md)',
                    background: activeForm === 'signup' ? 'var(--secondary-bg)' : 'none',
                    border: 'none',
                    color: activeForm === 'signup' ? 'var(--text-primary)' : 'var(--text-secondary)',
                    fontFamily: 'inherit',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}
                  onClick={() => setActiveForm('signup')}
                >
                  Sign Up
                </button>
              </div>
              
              <div style={{ padding: 'var(--spacing-xl)' }}>
                {activeForm === 'login' ? (
                  <LoginForm onLogin={onLogin} />
                ) : (
                  <SignUpForm onLogin={onLogin} />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default SplashPage;