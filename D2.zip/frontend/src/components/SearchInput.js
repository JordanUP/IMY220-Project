import React from "react";

const SearchInput = () => {
    return (
        <input type="text" placeholder="Search..." />
    );
};

export default SearchInput;
