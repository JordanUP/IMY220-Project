import React from 'react';

const dummyFiles = ['File1.txt', 'File2.txt', 'File3.txt'];

const Files = () => {
    return (
        <aside>
            <h2>Files</h2>
            <ul>
                {dummyFiles.map((file, index) => (
                    <li key={index}>{file}</li>
                ))}
            </ul>
        </aside>
    );
};

export default Files;
