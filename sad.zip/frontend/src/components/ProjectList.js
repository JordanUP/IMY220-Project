import React, { useState, useEffect } from 'react';
import ProjectPreview from './ProjectPreview'; // Import preview

const ProjectList = ({ userId }) => { // Component for user's projects
  const [projects, setProjects] = useState([]); // State for projects
  const [loading, setLoading] = useState(true); // Loading

  useEffect(() => { // Fetch on mount
    async function fetchProjects() {
      try {
        const res = await fetch('/api/projects?type=local&userId=' + userId); // Fetch local projects
        if (!res.ok) throw new Error('Fetch failed');
        const data = await res.json();
        setProjects(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchProjects(); // Call
  }, [userId]); // Dep on userId

  if (loading) return <p>Loading projects...</p>;

  return ( // Render.
    <section>
      {projects.map(project => ( // Map.
        <ProjectPreview key={project._id} project={project} /> // Render.
      ))}
    </section>
  );
};

export default ProjectList; // Export for Profile.