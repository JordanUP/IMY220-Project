import React from 'react';

const Files = ({ files }) => ( // Component for rendering files
  <section>
    <h3>Files</h3>
    <ul>
      {files.map((file, index) => ( // Map over files array
        <li key={index} >
          <a href={file} download>Download {file}</a>
        </li>
      ))}
    </ul>
  </section>
);

export default Files;
