import React from 'react';
import ProfilePreview from './ProfilePreview';

const Friends = ({ userId }) => { // Component for friends list 
  const [friends, setFriends] = useState([]); // State for friends
  const [loading, setLoading] = useState(true); // Loading

  useEffect(() => { // Fetch on mount
    async function fetchFriends() { // Async fetch
      try {
        const res = await fetch(`/api/users/${userId}`); // Fetch user to get friends array
        if (!res.ok) throw new Error('Fetch failed');
        const data = await res.json();
        setFriends(data.friends || []); // Update with friends IDs, but to show names, fetch each (or populate in backend)
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchFriends();
  }, [userId]); // Dep on userId

  const handleAddFriend = async (friendId) => { // Add friend func
    try {
      const res = await fetch(`/api/users/${userId}/friend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      if (!res.ok) throw new Error('Add failed');
      setFriends([...friends, friendId]); // Update local state
    } catch (err) {
      alert('Add failed: ' + err.message);
    }
  };

  const handleUnfriend = async (friendId) => { // Unfriend func
    try {
      const res = await fetch(`/api/users/${userId}/unfriend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      if (!res.ok) throw new Error('Unfriend failed');
      setFriends(friends.filter(id => id !== friendId)); // Update local state
    } catch (err) {
      alert('Unfriend failed: ' + err.message);
    }
  };

  if (loading) return <p>Loading friends...</p>; // Loading state

  return ( // Render
    <aside>
      <h3>Friends</h3>
      {friends.map((friendId, index) => ( // Map IDs (for full previews, fetch each user)
        <div key={index}>
          <ProfilePreview profileId={friendId} />
          <button onClick={() => handleUnfriend(friendId)}>Unfriend</button>
        </div>
      ))}
      <input type="text" placeholder="Friend ID to add" onKeyDown={(e) => e.key === 'Enter' && handleAddFriend(e.target.value)} />
    </aside>
  );
};

export default Friends;