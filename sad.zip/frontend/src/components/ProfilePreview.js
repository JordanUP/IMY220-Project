import React from "react";

const ProfilePreview = ({ profile }) => { // Component for rendering profile preview
<aside className="space-y-1">
    <img src={profile.avatar} alt="Avatar" />
    <h4>{profile.name}</h4>
    <p>{profile.bio}</p>
</aside>
};

export default ProfilePreview;
