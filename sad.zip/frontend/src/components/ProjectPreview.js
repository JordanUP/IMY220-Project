import React from "react";

const ProjectPreview = ({ project }) => {
    return (
        <article>
            <h3>{project.name}</h3>
            <p>{project.description}</p>
            <p>Contributors: {project.members.join(', ')}</p>
        </article>
    );
};

export default ProjectPreview;
