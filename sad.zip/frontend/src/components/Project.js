import React from 'react';

const Project = ({ project }) => {// Component for rendering a project detailed view
    <article>
        <h2>{project.name}</h2>
        <p>{project.description}</p>
        <p>Type: {project.type}</p>
        <p>Hashtags: {project.hashtags.join(', ')}</p>
  </article>
};

export default Project;
