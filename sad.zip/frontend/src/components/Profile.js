import React from 'react'; // React

const Profile = ({ user }) => ( // Component for displaying profile
  <section>
    <h2> {user.name}</h2>
    <p>{user.bio}</p>
    <img src={user.avatar} alt="Avatar" />
  </section>
);

export default Profile; // Export for Profile page.