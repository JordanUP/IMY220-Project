import React from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const LoginForm = () => { // Login form component
    const [email, setEmail] = useState("");// State for email input
    const [password, setPassword] = useState("");// State for password input
    const navigate = useNavigate();// Hook for navigation

    const handleSubmit = async (e) => {// Handle form submission asynchronously
        e.preventDefault();// Prevent default form submission (reloading the page)
        if (!email.includes("@") || password.length < 8) {// Basic validation
            alert("Please enter a valid email and a password with at least 8 characters.");
            return
        }
        fetch('/api/login', {// Send login request to backend
            method: 'POST',// Use POST method
            headers: { 'Content-Type': 'application/json' },// Set content type to JSON
            body: JSON.stringify({ email, password }),// Send email and password in request body
        })
        .then(res => res.json())// Parse response as JSON
        .then(data => {// Handle response data
            localStorage.setItem('userId', data._id);// Store userId in local storage
            alert('Login successful');// Show success alert
            navigate('/home');  // Redirect to home page
        })
        .catch(err => {
            console.error('Fetch error:', err);
            alert('Login failed: ' + err.message);
        });
    };

    return (//render the login form
        <form onSubmit={handleSubmit}>
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} required />
            <button type="submit">Login</button>
        </form>
    );
};

export default LoginForm;

I think I figured out why it isn't working. The login is accepting any email and password, so i don't think it's getting the right user ID. Please help me figure out how to fix this