import React from 'react';

const EditProfile = ({ userId }) => { // Component for editing profile
  const [bio, setBio] = useState(''); // State for bio

  const handleSubmit = async (e) => { // Async submit
    e.preventDefault(); // Prevent reload
    try {
      const res = await fetch(`/api/users/${userId}`, { // Fetch PUT
        method: 'PUT', // PUT for update
        headers: { 'Content-Type': 'application/json' }, // JSON header
        body: JSON.stringify({ bio }) // Send updates
      });
      if (!res.ok) throw new Error('Update failed');
      alert('Profile updated'); // Feedback
      // Optional: Re-fetch user in parent
    } catch (err) {
      alert('Update failed: ' + err.message); // Error feedback
    }
  };

  return ( // Render
    <form onSubmit={handleSubmit} className="space-y-4">
      <textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Bio"></textarea>
      <button type="submit">Save Profile</button>
    </form>
  );
};

export default EditProfile;