import React from "react";
import {Link, useNavigate} from "react-router-dom";

const Header = () => {
    const navigate = useNavigate(); // Hook for navigation
    const userId = localStorage.getItem('userId'); // Get logged-in ID for dynamic profile link (fixes undefined ID)
    const handleLogout = () => {// Handle user logout
        localStorage.clear(); // Clear local storage on logout
        navigate("/");// Redirect to home page after logout
    };

    return (
        <header>
            <nav>
                <img/>
                <ul>
                    <li><Link to="/home">Home</Link></li>
                    <li><Link to="/projects">Projects</Link></li>
                    <li><Link to="/profile">Profile</Link></li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;