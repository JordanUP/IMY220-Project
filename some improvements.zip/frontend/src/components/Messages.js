import React from 'react';

const Messages = ({ checkins }) => ( // Component for rendering check-in messages
  <section>
    <h3 >Check-in Messages</h3>
    <ul>
      {checkins.map((checkin, index) => ( // Map over checkins array
        <li key={index} className="font-code"> 
          {checkin.message} by User {checkin.user} on {checkin.date} (Version: {checkin.version})
        </li>
      ))}
    </ul>
  </section>
);

export default Messages;
