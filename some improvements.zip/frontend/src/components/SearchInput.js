import React, { useState } from 'react';

const SearchInput = () => { // Component for search input
  const [query, setQuery] = useState(''); // State for query
  const [results, setResults] = useState({ users: [], projects: [] }); // State for results

  const handleSearch = async () => { // Async search
    try {
      const res = await fetch(`/api/search?q=${query}`); // Fetch with query
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json(); // Parse { users, projects }
      setResults(data); // Update state
    } catch (err) {
      alert('Search failed: ' + err.message);
    }
  };

  return ( // Render.
    <div>
      <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSearch()} placeholder="Search projects or users" />
      <button onClick={handleSearch}>Search</button>
      {/* Render results */}
      <div>
        <h3>Users</h3>
        {results.users.map(user => <p key={user._id}>{user.name}</p>)}
        <h3>Projects</h3>
        {results.projects.map(project => <p key={project._id}>{project.name}</p>)}
      </div>
    </div>
  );
};

export default SearchInput; // Export for Home page.