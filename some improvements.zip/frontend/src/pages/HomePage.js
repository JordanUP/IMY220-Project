import React, { useState, useEffect } from 'react'; // Hooks.
import Feed from '../components/Feed'; // Feed.
import SearchInput from '../components/SearchInput'; // Search.

const HomePage = () => { // Home page (rubric p: feeds).
  const [projects, setProjects] = useState([]); // Projects state.
  const [isLocal, setIsLocal] = useState(true); // Switch.
  const [loading, setLoading] = useState(true); // Loading.
  const userId = localStorage.getItem('userId'); // Logged-in ID.

  useEffect(() => { // Fetch on changes.
    async function fetchProjects() {
      try {
        let url = '/api/projects'; // Default global.
        if (isLocal) { // If local.
          if (!userId) { // Handle undefined userId (not logged in).
            alert('Log in for local feed');
            setIsLocal(false); // Fallback to global.
            return;
          }
          url = `/api/projects?type=local&userId=${userId}`; // Local with ID (fixes undefined error).
        }
        const res = await fetch(url); // Fetch.
        if (!res.ok) throw new Error('Fetch failed');
        const data = await res.json();
        setProjects(data);
      } catch (err) {
        console.error(err);
        alert('Failed to load feed: ' + err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchProjects();
  }, [isLocal, userId]); // Dep on switch and userId.

  if (loading) return <p>Loading...</p>;

  return (
    <main>
      <SearchInput />
      <button onClick={() => setIsLocal(!isLocal)} >Switch to {isLocal ? 'Global' : 'Local'} Feed</button>
      <Feed projects={projects} />
    </main>
  );
};

export default HomePage; // Export.