import React, { useState, useEffect } from 'react'; // Import React and hooks: useState for managing component state (e.g., project data, form inputs), useEffect for side effects like fetching data on mount or after updates.
import { useParams, useNavigate } from 'react-router-dom'; // useParams to extract the dynamic :id from the URL (for viewing specific project, rubric l: Viewing), useNavigate for programmatic navigation (e.g., redirect after delete, rubric m: Delete own projects).

import Project from '../components/Project'; // Import child component to display basic project info like name, desc, type, hashtags (rubric l: Viewing with all required info).
import Files from '../components/Files'; // Import child component for listing and downloading project files (rubric l: Downloading vs. Checking out - download files).
import Messages from '../components/Messages'; // Import child component for displaying check-in messages (rubric l: check-in with message).
import EditProject from '../components/EditProject'; // Import child component for editing project (rubric m: Edit own projects).

const ProjectPage = () => { // Main Project page component (rubric l: Project Viewing/Collaboration - view details, check out/in with changes/message/files, rubric m: Edit/Delete own).
  const { id } = useParams(); // Get the project ID from the URL (dynamic route /project/:id from App.js, allows viewing specific project).
  const navigate = useNavigate(); // Hook to navigate to other routes (e.g., back to home after delete).
  const [project, setProject] = useState(null); // State to hold the fetched project data (starts as null, no dummy data, rubric d: pull from database).
  const [loading, setLoading] = useState(true); // State for loading indicator while fetching (provides user feedback, rubric g: no errors by handling async).
  const [message, setMessage] = useState(''); // State for check-in message input (rubric l: check-in with message).
  const [files, setFiles] = useState([]); // State for check-in files (rubric l: updated files).
  const currentUserId = localStorage.getItem('userId'); // Get logged-in user ID (to check if owner for edit/delete, simple auth).

  useEffect(() => { // Effect hook to run fetch when component mounts or ID changes.
    async function fetchProject() { // Async function for await on Fetch (rubric h: Native Fetch API).
      try { // Try block to catch errors during fetch (rubric g: no browser console errors by handling them).
        const response = await fetch(`/api/projects/${id}`); // Native Fetch to GET /api/projects/:id (rubric h, pulls real data from backend, rubric d/a: pull from MongoDB via backend for viewing).
        if (!response.ok) throw new Error('Fetch failed - project not found or server error'); // Check if response is OK (200), throw if 404/500 from backend.
        const data = await response.json(); // Parse the JSON response (project object from backend).
        setProject(data); // Update state with fetched data (now renders with real DB project, no dummies).
      } catch (err) { // Catch network or server errors.
        console.error('Fetch error:', err); // Log to console for dev debugging (rubric g: handle to avoid uncaught errors).
        alert('Failed to load project: ' + err.message); // User-friendly alert (UX, rubric g).
      } finally { // Always run after try/catch, regardless of success/error.
        setLoading(false); // Stop the loading indicator to show content or error message.
      }
    }
    if (id && id !== 'undefined') { // Check if id is defined before fetching (fixes undefined error if navigated to /project without ID).
      fetchProject(); // Call the async function only if id is valid.
    } else { // If id undefined, handle error (e.g., redirect or message).
      setLoading(false);
      alert('Invalid project ID');
      navigate('/home'); // Redirect to home if id undefined.
    }
  }, [id, navigate]); // Dependency array: re-run effect if the ID or navigate changes.

  const handleCheckout = async () => { // Function to handle check-out (rubric l: Check out a project to make changes).
    try { // Try block for Fetch.
      const response = await fetch(`/api/projects/${id}/checkout`, { // Native Fetch to POST /api/projects/:id/checkout (rubric h).
        method: 'POST', // POST method.
        headers: { 'Content-Type': 'application/json' }, // JSON header.
        body: JSON.stringify({ userId: currentUserId }) // Send logged-in user ID.
      });
      if (!response.ok) throw new Error('Checkout failed - server error'); // Check status.
      alert('Project checked out successfully'); // Feedback.
      fetchProject(); // Re-fetch to update status (refresh page data).
    } catch (err) { // Catch error.
      console.error('Checkout error:', err); // Log.
      alert('Checkout failed: ' + err.message); // User message (rubric g).
    }
  };

  const handleCheckin = async (e) => { // Function to handle check-in form submit (rubric l: check it back in with updated files and a message).
    e.preventDefault(); // Prevent default form submission (page reload).
    const formData = new FormData(); // Use FormData for multipart (files + message, rubric l: updated files).
    formData.append('user', currentUserId); // Append user ID.
    formData.append('message', message); // Append message.
    files.forEach(file => formData.append('files', file)); // Append multiple files (rubric l: updated files).

    try { // Try block for Fetch.
      const response = await fetch(`/api/projects/${id}/checkin`, { // Native Fetch to POST /api/projects/:id/checkin (rubric h).
        method: 'POST', // POST method.
        body: formData // Send FormData (browser sets Content-Type multipart).
      });
      if (!response.ok) throw new Error('Checkin failed - server error'); // Check status.
      alert('Project checked in successfully'); // Feedback.
      setMessage(''); // Clear message input.
      setFiles([]); // Clear files.
      fetchProject(); // Re-fetch to update checkins array.
    } catch (err) { // Catch error.
      console.error('Checkin error:', err); // Log.
      alert('Checkin failed: ' + err.message); // User message (rubric g).
    }
  };

  const handleDelete = async () => { // Function to handle project deletion (rubric m: Delete own projects, only for own).
    if (project.owner !== currentUserId) { // Check if logged-in user is owner (prevent deleting other's).
      alert('You can only delete your own projects');
      return;
    }
    if (window.confirm('Are you sure you want to delete this project? This cannot be undone.')) { // Confirmation (good UX).
      try { // Try block for Fetch.
        const response = await fetch(`/api/projects/${id}`, { // Native Fetch to DELETE /api/projects/:id (rubric h).
          method: 'DELETE' // DELETE method to remove from DB.
        });
        if (!response.ok) throw new Error('Delete failed - server error'); // Check status.
        alert('Project deleted successfully'); // Feedback.
        navigate('/home'); // Redirect to home after delete.
      } catch (err) { // Catch error.
        console.error('Delete error:', err); // Log.
        alert('Delete failed: ' + err.message); // User message (rubric g).
      }
    }
  };

  if (loading) return <p className="text-center text-gray-500 font-code">Loading project...</p>; // Conditional loading UI with Tailwind (rubric s/t: theme, g: no errors during load).
  if (!project) return <p className="text-center text-red-500 font-code">Project not found or error loading</p>; // Conditional error UI if fetch fails or project not found.

  const isOwner = project.owner === currentUserId; // Boolean to check if logged-in user is owner (show edit/delete only for own, rubric m: own projects).

  return ( // Main JSX to render the page content.
    <main className="p-4 bg-teal-100 font-code space-y-4"> // Tailwind classes: padding, teal background, code font, spacing (rubric s/t: implemented colors/theme across website).
      <Project project={project} /> // Render basic project info component, passing fetched project data (rubric l: Viewing with all required info).
      <Files files={project.files || []} /> // Render files component for download (rubric l: Downloading vs. Checking out - download project files).
      <Messages checkins={project.checkins || []} /> // Render check-in messages component (rubric l: check-in with message).
      {isOwner && <EditProject projectId={id} />} // Conditional render: Show edit form only for own project (rubric m: Edit own projects).
      {isOwner && <button onClick={handleDelete} className="bg-red-500 text-white p-2 rounded hover:bg-red-600 font-code">Delete Project</button>} // Conditional delete button with Tailwind hover (rubric m: Delete own projects, s/t: colors).
      <button onClick={handleCheckout} className="bg-yellow-500 text-teal-900 p-2 rounded hover:bg-yellow-600 font-code">Check Out</button> // Button for check-out (rubric l: Check out a project to make changes).
      <form onSubmit={handleCheckin} className="space-y-4"> // Form for check-in (rubric l: check it back in with updated files and a message).
        <textarea value={message} onChange={(e) => setMessage(e.target.value)} className="border p-2 w-full rounded font-code" placeholder="Check-in Message" /> // Textarea for message (rubric l).
        <input type="file" multiple onChange={(e) => setFiles(Array.from(e.target.files))} className="border p-2 w-full" /> // File input for multiple updated files (rubric l).
        <button type="submit" className="bg-yellow-500 text-teal-900 p-2 rounded font-code w-full hover:bg-yellow-600">Check In</button> // Submit button with hover (rubric s/t).
      </form>
    </main>
  );
};

export default ProjectPage; // Export the component for use in App.js routes (D1 Part 4: routing).