import React, { useState, useEffect } from 'react'; // Import React and hooks: useState for managing component state (e.g., user data), useEffect for side effects like fetching data on mount or when dependencies change.
import { useParams, useNavigate } from 'react-router-dom'; // useParams to extract the dynamic :id from the URL (for viewing own or other's profile, rubric j: View someone else's), useNavigate for programmatic navigation (e.g., redirect after delete, rubric j: Delete your profile).

import Profile from '../components/Profile'; // Import child component to display basic profile info like name and bio (rubric j: View).
import EditProfile from '../components/EditProfile'; // Import child component for editing profile form (rubric j: Edit).
import ProjectList from '../components/ProjectList'; // Import child component to list the user's projects (rubric p: activity feeds, shows local projects for the user).
import FriendsList from '../components/FriendsList'; // Import child component for displaying and managing friends list (rubric k: Friend/Unfriend).
import CreateProject from '../components/CreateProject'; // Import child component for creating a new project from the profile page (rubric l: Project Creation, as spec allows creating from profile).

const ProfilePage = () => { // Main Profile page component (rubric j: full profile management - view, edit, delete, view others via :id).
  const { id } = useParams(); // Extract the user ID from the URL path (dynamic routing from App.js, allows viewing any profile by ID, rubric j: View someone else's).
  const navigate = useNavigate(); // Hook to navigate to other routes (e.g., back to home after delete).
  const [user, setUser] = useState(null); // State to hold the fetched user data (starts as null, no dummy data, rubric d: pull from database).
  const [loading, setLoading] = useState(true); // State for loading indicator while fetching (provides user feedback, rubric g: no errors by handling async).
  const currentUserId = localStorage.getItem('userId'); // Get the logged-in user's ID from localStorage (set during login, used to check if this is the user's own profile for edit/delete/create, simple auth).

  useEffect(() => { // Effect hook to run code after render (fetch data when component mounts or ID changes).
    async function fetchUser() { // Async function inside effect to use await for Fetch (rubric h: Native Fetch API).
      try { // Try block to catch errors during fetch (rubric g: no browser console errors by handling them).
        const response = await fetch(`/api/users/${id}`); // Native Fetch to GET /api/users/:id (rubric h, pulls real data from backend API, rubric d/a: pull from MongoDB via backend).
        if (!response.ok) throw new Error('Fetch failed - user not found or server error'); // Check if response is OK (200), throw if 404/500 from backend.
        const data = await response.json(); // Parse the JSON response (user object from backend).
        setUser(data); // Update state with fetched data (now renders with real DB user, no dummies).
      } catch (err) { // Catch network or server errors.
        console.error('Fetch error:', err); // Log to console for dev debugging (rubric g: handle to avoid uncaught errors).
        alert('Failed to load profile: ' + err.message); // User-friendly alert (UX, rubric g).
      } finally { // Always run after try/catch, regardless of success/error.
        setLoading(false); // Stop the loading indicator to show content or error message.
      }
    }
    if (id && id !== 'undefined') { // Check if id defined and not 'undefined' string (fixes error).
      fetchUser();
    } else { // Handle undefined id.
      setLoading(false);
      alert('Invalid profile ID');
      navigate('/home'); // Redirect.
    }
  }, [id]); // Dependency array: re-run effect if the ID changes (e.g., navigating to another profile).

  const handleDelete = async () => { // Function to handle profile deletion (rubric j: Delete your profile, only available for own profile).
    if (id !== currentUserId) { // Security check: only allow delete if this is the logged-in user's own profile (prevent deleting others).
      alert('You can only delete your own profile');
      return;
    }
    if (window.confirm('Are you sure you want to delete your profile? This cannot be undone.')) { // Confirmation dialog to prevent accidental delete (good UX).
      try { // Try block for Fetch.
        const response = await fetch(`/api/users/${id}`, { // Native Fetch to DELETE /api/users/:id (rubric h).
          method: 'DELETE' // DELETE method to remove from DB.
        });
        if (!response.ok) throw new Error('Delete failed - server error'); // Check status.
        localStorage.clear(); // Clear stored userId (effectively logs out, rubric i: Logout).
        alert('Profile deleted successfully'); // Feedback.
        navigate('/'); // Redirect to splash page after delete.
      } catch (err) { // Catch error.
        console.error('Delete error:', err); // Log.
        alert('Delete failed: ' + err.message); // User message (rubric g).
      }
    }
  };

  if (loading) return <p className="text-center text-gray-500 font-code">Loading profile...</p>; // Conditional loading UI with Tailwind styling (rubric s/t: theme, g: no errors during load).
  if (!user) return <p className="text-center text-red-500 font-code">Profile not found or error loading</p>; // Conditional error UI if fetch fails or user not found.

  const isOwnProfile = id === currentUserId; // Boolean to check if this is the logged-in user's own profile (show edit/delete/create only for own, rubric j: edit/delete own).

  return ( // Main JSX to render the page content.
    <main>
      <Profile user={user} /> 
      {isOwnProfile && <EditProfile userId={id} />} 
      {isOwnProfile && <button onClick={handleDelete} >Delete Profile</button>} 
      <ProjectList userId={id} />
      <FriendsList userId={id} />
      {isOwnProfile && <CreateProject />}
    </main>
  );
};

export default ProfilePage; // Export the component for use in App.js routes (D1 Part 4: routing).