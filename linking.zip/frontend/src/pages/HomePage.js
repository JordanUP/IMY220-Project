import React, {useState, useEffect} from 'react';
import Feed from '../components/Feed';
import SearchInput from '../components/SearchInput';


const Home = () => { // Home page
  const [projects, setProjects] = useState([]); // State for projects
  const [isLocal, setIsLocal] = useState(true); // State for local/global switch
  const [loading, setLoading] = useState(true); // Loading

  useEffect(() => { // Fetch on mount/isLocal change
    async function fetchProjects() {
      try {
        const userId = localStorage.getItem('userId'); // Get logged-in user
        const url = isLocal ? `/api/projects?type=local&userId=${userId}` : '/api/projects'; // Query for local/global
        const res = await fetch(url); // Fetch
        if (!res.ok) throw new Error('Fetch failed');
        const data = await res.json();
        setProjects(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchProjects();
  }, [isLocal]); // Dep on switch

  if (loading) return <p>Loading...</p>;

  return ( // Render
    <main>
      <SearchInput />
      <button onClick={() => setIsLocal(!isLocal)} >Switch to {isLocal ? 'Global' : 'Local'} Feed</button>
      <Feed projects={projects} />
    </main>
  );
};

export default Home;