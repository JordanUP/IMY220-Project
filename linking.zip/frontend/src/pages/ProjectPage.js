import React, { useState, useEffect } from 'react'; // Hooks
import { useParams, useNavigate } from 'react-router-dom'; // Params for ID, navigate for delete
import Project from '../components/Project'; // Details
import Files from '../components/Files'; // Files
import Messages from '../components/Messages'; // Check-ins
import EditProject from '../components/EditProject'; // Edit

const ProjectPage = () => { // Project page
  const { id } = useParams(); // Get project ID from URL
  const navigate = useNavigate(); // For delete
  const [project, setProject] = useState(null); // State for project
  const [loading, setLoading] = useState(true); // Loading
  const [message, setMessage] = useState(''); // State for check-in message
  const [files, setFiles] = useState([]); // State for check-in files

  useEffect(() => { // Fetch on mount
    async function fetchProject() {
      try {
        const res = await fetch(`/api/projects/${id}`); // Fetch single project by ID
        if (!res.ok) throw new Error('Fetch failed');
        const data = await res.json();
        setProject(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchProject();
  }, [id]); // Dep on ID

  const handleCheckout = async () => { // Checkout func
    try {
      const res = await fetch(`/api/projects/${id}/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: localStorage.getItem('userId') })
      });
      if (!res.ok) throw new Error('Checkout failed');
      alert('Checked out');
      // Re-fetch project to update status
      fetchProject(); // Call again to refresh
    } catch (err) {
      alert('Checkout failed: ' + err.message);
    }
  };

  const handleCheckin = async (e) => { // Check-in form submit
    e.preventDefault(); // Prevent reload
    const formData = new FormData(); // For files/message
    formData.append('user', localStorage.getItem('userId'));
    formData.append('message', message);
    files.forEach(file => formData.append('files', file));
    try {
      const res = await fetch(`/api/projects/${id}/checkin`, {
        method: 'POST',
        body: formData
      });
      if (!res.ok) throw new Error('Checkin failed');
      alert('Checked in');
      setMessage(''); // Clear
      setFiles([]); // Clear
      fetchProject(); // Refresh
    } catch (err) {
      alert('Checkin failed: ' + err.message);
    }
  };

  const handleDelete = async () => { // Delete
    if (window.confirm('Delete project?')) {
      try {
        const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
        if (!res.ok) throw new Error('Delete failed');
        navigate('/home'); // Redirect
      } catch (err) {
        alert('Delete failed: ' + err.message);
      }
    }
  };

  if (loading) return <p>Loading...</p>;
  if (!project) return <p>Project not found</p>;

  return ( // Render
    <main className="p-4 font-code">
      <ProjectComponent project={project} />
      <Files files={project.files || []} />
      <Messages checkins={project.checkins || []} />
      <EditProject projectId={id} />
      <button onClick={handleDelete}>Delete Project</button>
      <button onClick={handleCheckout}>Check Out</button>
      {/* Check-in form */}
      <form onSubmit={(e) => { e.preventDefault(); handleCheckin(e.target.message.value, e.target.files.files); }}>
        <textarea name="message" placeholder="Message"></textarea>
        <input type="file" multiple name="files"  />
        <button type="submit">Check In</button>
      </form>
    </main>
  );
};

export default ProjectPage; // Export.