const connectDB = require('../dbconnect');  // Import connection func. to get DB instance
const { ObjectId } = require('mongodb');  //  For ID conversion in queries

// User functions:

// User document structure: { name: String (req), email: String (req, unique manual check), password: String (req), bio: String, avatar: String, friends: [ObjectId], projects: [ObjectId], createdAt: Date }
async function createUser(data) {  //  Async create user (for signup)
  const db = await connectDB();  //  Get DB (connects if needed)
  if (!data.name || !data.email || !data.password) throw new Error('Missing required user fields');  //  Manual validation
  const exists = await db.collection('users').findOne({ email: data.email });  //  Check for existing email manually
  if (exists) throw new Error('Email already in use');  //  If exists, error
  data.createdAt = new Date();  //  Default timestamp
  data.friends = [];  //  Default empty array for friends relationship
  data.projects = [];  //  Default empty array for projects relationship
  const result = await db.collection('users').insertOne(data);  //  Insert document into 'users' collection
  return { ...data, _id: result.insertedId };  //  Return with generated _id
}

async function getUsers() {  //  Fetch all users (for feeds/search)
  const db = await connectDB();  //  Get DB
  return await db.collection('users').find({}).toArray();  //  Find all docs, convert cursor to array (JSON-ready)
}

async function getUserById(id) {  //  Fetch single user by ID (for profile view)
  const db = await connectDB();
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  return await db.collection('users').findOne({ _id: objectId });  //  Find one doc by _id
}

async function getUserByEmail(email, password) {  //  Fetch single user by email (for login)
  const db = await connectDB();
  return await db.collection('users').findOne({ email, password });  //  Find one doc by email using simple query
}

async function updateUser(id, updates) {
  const db = await connectDB();
  const objectId = new ObjectId(id);
  
  // Remove undefined values
  Object.keys(updates).forEach(key => {
    if (updates[key] === undefined) {
      delete updates[key];
    }
  });

  const result = await db.collection('users').updateOne(
    { _id: objectId },
    { $set: updates }
  );
  
  if (result.modifiedCount === 0) {
    throw new Error('User not found or no changes made');
  }
  
  // Return the updated user
  const updatedUser = await db.collection('users').findOne({ _id: objectId });
  return updatedUser;
}

async function deleteUser(id) {  //  Delete user for own profile removal
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert ID
  const result = await db.collection('users').deleteOne({ _id: objectId });  //  Delete one by _id
  if (result.deletedCount === 0) throw new Error('User not found');  //  Check
  return { message: 'User deleted' };  //  Success
}

async function addFriend(userId, friendId) {  //  Add to friends array
  const db = await connectDB();  //  Get DB
  const userObjectId = new ObjectId(userId);  //  Convert
  const friendObjectId = new ObjectId(friendId);  //  Convert

  // Add friend to user's friends list AND user to friend's friends list
  await db.collection('users').updateOne(// Add to user's friends
    { _id: userObjectId },
    { $addToSet: { friends: friendObjectId } }
  );
  
  await db.collection('users').updateOne(// Add to friend's friends
    { _id: friendObjectId },
    { $addToSet: { friends: userObjectId } }
  );

  return { message: 'Friend added' };
}

async function removeFriend(userId, friendId) {  //  Remove from friends (unfriend)
  const db = await connectDB();  //  Get DB
  const userObjectId = new ObjectId(userId);
  const friendObjectId = new ObjectId(friendId);

  try {
    // Remove any projects shared between the two users
    const res1 = await db.collection('users').updateOne(
      { _id: userObjectId },
      { $pull: { friends: friendObjectId } }
    );

    const res2 = await db.collection('users').updateOne(
      { _id: friendObjectId },
      { $pull: { friends: userObjectId } }
    );

    if (res1.modifiedCount === 0 && res2.modifiedCount === 0) {
      throw new Error('Users are not friends/ already unfriended');
    }

    return { message: 'Friend removed' };
  
  } catch (err) {
    console.error('Error removing shared projects:', err);
    throw err;
  }
}

// Project functions:

// Project document structure: { name: String (req), description: String, image: String, type: String, hashtags: [String], owner: ObjectId (req), members: [ObjectId], checkins: [{ user: ObjectId, message: String, files: [String], version: String, date: Date }], status: String, checkedOutBy: ObjectId, createdAt: Date, version: String }
async function createProject(data) {
  const db = await connectDB();
  
  if (!data.name || !data.owner) {
    throw new Error('Missing required project fields: name and owner');
  }

  // Ensure owner is ObjectId
  data.owner = new ObjectId(data.owner);
  data.members = data.members ? data.members.map(id => new ObjectId(id)) : [data.owner];
  
  // Set defaults
  data.createdAt = new Date();
  data.version = '1.0.0';
  data.status = 'checked-in';
  data.checkedOutBy = null;
  data.hashtags = data.hashtags || [];
  data.type = data.type || 'other';

  // Create proper initial check-in
  const initialCheckin = {
    user: data.owner,
    message: 'Project created',
    version: data.version,
    date: data.createdAt,
    files: data.files || []
  };

  data.checkins = [initialCheckin];

  console.log('Creating project with initial check-in:', data);

  const result = await db.collection('projects').insertOne(data);
  return { ...data, _id: result.insertedId };
}

async function getProjects() {  //  Fetch all projects
  const db = await connectDB();  //  Get DB
  return await db.collection('projects').find({}).toArray();  //  Find all docs, convert cursor to array
}

async function getProjectById(id) {  //  Fetch single project by ID
  const db = await connectDB();
  const objectId = new ObjectId(id);  //  Convert string ID to ObjectId
  return await db.collection('projects').findOne({ _id: objectId });  //  Find one doc by _id
}

async function getProjectsByUserId(userId) {
  const db = await connectDB();
  
  try {
    console.log('Getting projects for user:', userId);
    
    // Validate and convert userId to ObjectId
    let objectId;
    try {
      objectId = new ObjectId(userId);
    } catch (err) {
      console.error('Invalid user ID:', userId, err);
      throw new Error('Invalid user ID format');
    }

    // Find projects where the user is either the owner or a member
    const projects = await db.collection('projects').find({
      $or: [
        { owner: objectId },
        { members: objectId }
      ]
    }).toArray();

    console.log(`Found ${projects.length} projects for user ${userId}`);
    return projects;
  } catch (err) {
    console.error('Error in getProjectsByUserId:', err);
    throw err;
  }
}

async function updateProject(id, updates) {  //  Edit project
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert
  const result = await db.collection('projects').updateOne({ _id: objectId }, { $set: updates });  //  Update
  if (result.modifiedCount === 0) throw new Error('Project not found or not modified');  //  Check
  return { message: 'Project updated' };  //  Success
}

async function deleteProject(id) {  //  Delete project
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert
  const result = await db.collection('projects').deleteOne({ _id: objectId });  //  Delete
  if (result.deletedCount === 0) throw new Error('Project not found');  //  Check
  return { message: 'Project deleted' };  //  Success
}

async function checkoutProject(id, userId) {  //  Checkout (set status, checkedOutBy)
  const db = await connectDB();  //  Get DB
  const objectId = new ObjectId(id);  //  Convert project ID
  const userObjectId = new ObjectId(userId);  //  Convert user ID
  const result = await db.collection('projects').updateOne({ _id: objectId }, { $set: { status: 'checked-out', checkedOutBy: userObjectId } });  //  Update
  if (result.modifiedCount === 0) throw new Error('Project not found');  //  Check
  return { message: 'Project checked out' };  //  Success
}

async function addCheckin(id, checkinData) {
  const db = await connectDB();
  const objectId = new ObjectId(id);
  
  console.log('Received checkin data:', checkinData);

  // Ensure all required fields are present
  if (!checkinData.user || !checkinData.message || !checkinData.version) {
    throw new Error('Missing required check-in fields: user, message, or version');
  }

  // Convert user ID to ObjectId
  checkinData.user = new ObjectId(checkinData.user);
  checkinData.date = new Date();
  checkinData.files = checkinData.files || [];

  console.log('Processed checkin data:', checkinData);

  const result = await db.collection('projects').updateOne(
    { _id: objectId }, 
    { 
      $push: { checkins: checkinData }, 
      $set: { 
        status: 'checked-in', 
        checkedOutBy: null,
        version: checkinData.version // Update the project version
      } 
    }
  );
  
  if (result.modifiedCount === 0) throw new Error('Project not found');
  
  console.log('Checkin added successfully');
  return { message: 'Check-in added', version: checkinData.version };
}

async function search(query) {  //  Search users/projects (multi-field $regex)
  const db = await connectDB();  //  Get DB
  const regex = new RegExp(query, 'i');  //  Case-insensitive regex
  const users = await db.collection('users').find({ $or: [{ name: regex }, { email: regex }] }).toArray();  //  Search users by name/email
  const projects = await db.collection('projects').find({ $or: [{ name: regex }, { type: regex }, { hashtags: regex }, { 'checkins.message': regex }] }).toArray();  //  Search projects by name/type/hashtags/check-in message
  return { users, projects };  //  Return combined results for frontend
}

async function getLocalProjects(userId) {  //  Fetch all projects for local user
  const db = await connectDB();
  const objectId = new ObjectId(userId); // Convert user ID
  const user = await db.collection('users').findOne({ _id: objectId }, { projection: { friends: 1, projects: 1 } }); // Get user's friends/projects.
  const friendIds = user.friends || []; // Get friends or empty array.
  const projectIds = user.projects || []; // Get user's own projects or empty array.
  const allIds = [...friendIds, objectId]; // Include own + friends.
  return await db.collection('projects').find({ $or: [{ owner: { $in: allIds } }, { members: { $in: allIds } }, { _id: { $in: projectIds } }] }).toArray(); // Find projects owned/membered by user/friends.
}

module.exports = { createUser, getUsers, getUserById, getUserByEmail, updateUser, deleteUser, addFriend, removeFriend, createProject, getProjects, getProjectById, getProjectsByUserId, updateProject, deleteProject, checkoutProject, addCheckin, search, getLocalProjects };  //  Export all functions for api.js (Full CRUD)