const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');

const { 
  createUser, getUsers, getUserById, getUserByEmail, updateUser, deleteUser, addFriend, removeFriend,
  createProject, getProjects, getProjectById, getProjectsByUserId, updateProject, deleteProject, checkoutProject, addCheckin,
  search, getLocalProjects
} = require('../utils/db');

// --- User Routes ---

router.get('/users', async (req, res) => {
  try {
    const users = await getUsers();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/users/:id', async (req, res) => {
  try {
    const user = await getUserById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET projects by user ID - for user profile pages
router.get('/users/:id/projects', async (req, res) => {
  try {
    console.log('Fetching projects for user:', req.params.id);
    
    // Validate that the user exists first
    const user = await getUserById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const projects = await getProjectsByUserId(req.params.id);
    console.log(`Returning ${projects.length} projects for user ${req.params.id}`);
    res.json(projects);
  } catch (err) {
    console.error('Error in /users/:id/projects:', err);
    res.status(500).json({ error: err.message });
  }
});

router.post('/users', async (req, res) => {
  try {
    const user = await createUser(req.body);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    delete updates._id;
    delete updates.password;
    delete updates.friends;
    delete updates.projects;
    
    const result = await updateUser(id, updates);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/users/:id', async (req, res) => {
  try {
    const result = await deleteUser(req.params.id);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/users/:id/friend', async (req, res) => {
  try {
    const result = await addFriend(req.params.id, req.body.friendId);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/users/:id/unfriend', async (req, res) => {
  try {
    const result = await removeFriend(req.params.id, req.body.friendId);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Project Routes ---

// GET all projects - For activity feeds
router.get('/projects', async (req, res) => {
  try {
    let projects;
    
    if (req.query.type === 'local' && req.query.userId) {
      console.log('Fetching local projects for user:', req.query.userId);
      
      // Validate userId format first
      if (!ObjectId.isValid(req.query.userId)) {
        return res.status(400).json({ error: 'Invalid user ID format' });
      }
      
      projects = await getLocalProjects(req.query.userId);
      console.log(`Found ${projects.length} local projects for user ${req.query.userId}`);
    } else {
      console.log('Fetching all global projects');
      projects = await getProjects();
      console.log(`Found ${projects.length} global projects`);
    }
    
    // Always return an array, even if empty
    res.json(projects || []);
  } catch (err) {
    console.error('Error in /projects route:', err);
    res.status(500).json({ error: err.message });
  }
});

// GET project by ID
router.get('/projects/:id', async (req, res) => {
  try {
    const project = await getProjectById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/projects', async (req, res) => {
  try {
    const project = await createProject(req.body);
    res.json(project);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/projects/:id', async (req, res) => {
  try {
    const result = await updateProject(req.params.id, req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/projects/:id', async (req, res) => {
  try {
    const result = await deleteProject(req.params.id);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/projects/:id/checkout', async (req, res) => {
  try {
    const result = await checkoutProject(req.params.id, req.body.userId);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/projects/:id/checkin', async (req, res) => {
  try {
    console.log('Checkin API called with body:', req.body);
    const result = await addCheckin(req.params.id, req.body);
    res.json(result);
  } catch (err) {
    console.error('Checkin API error:', err);
    res.status(500).json({ error: err.message });
  }
});

router.get('/search', async (req, res) => {
  try {
    const result = await search(req.query.q || '');
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const user = await getUserByEmail(email, password);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/signup', async (req, res) => {
  try {
    const user = await createUser(req.body);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;