const path = require('path'); // Node path for handling file paths
const HtmlWebpackPlugin = require('html-webpack-plugin'); // Plugin to generate HTML file

module.exports = {
    entry: './frontend/src/index.js',
    output: {
        filename: 'bundle.js',// Output file name
        path: path.resolve(__dirname, 'dist'),// Output directory
        publicPath: '/',// Public URL of the output directory when referenced in a browser
    },
    module: {// Module rules for different file types
        rules: [
            {
                test: /\.(js|jsx)$/,// Regex to match .js and .jsx files
                exclude: /node_modules/,// Exclude node_modules directory
                use: 'babel-loader'// Use Babel loader for transpiling JavaScript files
            },
            {
                test: /\.css$/,// for .css files
                use: ['style-loader', 'css-loader']// Use style-loader and css-loader for CSS files
            }
        ]
    },
    plugins: [
        new HtmlWebpackPlugin({// Generate an HTML file that includes the webpack bundle
            template: path.resolve(__dirname, 'frontend/public/index.html'),// Template file
        }),
    ],
    resolve: {
        extensions: ['.js', '.jsx'] // Allow importing JS and JSX files without specifying extensions
    },
    devServer: {
        static: path.join(__dirname, 'dist'),// Serve static files from the dist directory
        port: 3000,// Port number for the dev server
        historyApiFallback: true,// Enable support for HTML5 History API
        proxy: [// Proxy configuration to redirect API calls
            {
                context: ['/api'],
                target: 'http://localhost:5000',
                changeOrigin: true,
            }
        ]
    },
    mode: 'development' // Set the mode to development
};
