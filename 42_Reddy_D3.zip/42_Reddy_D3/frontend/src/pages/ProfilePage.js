import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import EditProfile from '../components/EditProfile';
import ProjectList from '../components/ProjectList';
import FriendsList from '../components/FriendsList';

const ProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Use the navigation state if available, otherwise default to false
  const [isFriend, setIsFriend] = useState(location.state?.isFriend || false);
  
  const getCurrentUserId = () => {
    const userId = localStorage.getItem('userId');
    return userId && userId !== 'undefined' ? userId : null;
  };
  
  const currentUserId = getCurrentUserId();
  const profileId = id || currentUserId;
  const isOwnProfile = !id || id === currentUserId;

  const fetchUserData = async () => {
    try {
      if (!profileId) {
        navigate('/');
        return;
      }
      
      // Fetch the profile user
      const userResponse = await fetch(`/api/users/${profileId}`);
      if (!userResponse.ok) throw new Error('User not found');
      const userData = await userResponse.json();
      setUser(userData);

      // Only fetch current user data if we don't already know the friendship status
      // or if we need to verify/update it
      if (currentUserId && !isOwnProfile) {
        const currentUserResponse = await fetch(`/api/users/${currentUserId}`);
        if (currentUserResponse.ok) {
          const currentUserData = await currentUserResponse.json();
          setCurrentUser(currentUserData);
          
          // Always update friendship status from the server to ensure accuracy
          const areFriends = currentUserData.friends && 
            currentUserData.friends.some(friendId => {
              const friendIdStr = friendId.toString ? friendId.toString() : friendId;
              const profileIdStr = profileId.toString ? profileId.toString() : profileId;
              return friendIdStr === profileIdStr;
            });
          setIsFriend(areFriends);
        }
      }
    } catch (err) {
      console.error('Fetch error:', err);
      navigate('/home');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, [profileId, navigate]);

  // Clear the navigation state after using it to prevent stale data
  useEffect(() => {
    if (location.state?.fromSearch) {
      // Replace the current location to clear the state
      navigate(location.pathname, { replace: true });
    }
  }, [location, navigate]);

  // Rest of the component remains the same...
  const handleProfileUpdate = (updatedUser) => {
    setUser(updatedUser);
  };

  const handleAddFriend = async () => {
    if (!currentUserId) {
      return;
    }

    try {
      const response = await fetch(`/api/users/${currentUserId}/friend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId: profileId })
      });
      
      if (!response.ok) throw new Error('Failed to send friend request');
      
      setIsFriend(true);
      fetchUserData(); // Refresh to get updated data
    } catch (err) {
      console.error('Add friend error:', err);
    }
  };

  const handleRemoveFriend = async () => {
    if (!currentUserId) {
      return;
    }

    try {
      const response = await fetch(`/api/users/${currentUserId}/unfriend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId: profileId })
      });
      
      if (!response.ok) throw new Error('Failed to remove friend');
      
      setIsFriend(false);
      fetchUserData(); // Refresh to get updated data
    } catch (err) {
      console.error('Remove friend error:', err)
    }
  };

  const handleDelete = async () => {
    if (!isOwnProfile) {
      console.error('Unauthorized delete attempt');
      return;
    }
    
    if (window.confirm('Are you sure you want to delete your profile? This cannot be undone.')) {
      try {
        const response = await fetch(`/api/users/${profileId}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Delete failed');
        
        localStorage.clear();
        navigate('/');
      } catch (err) {
        console.error('Delete error:', err);
      }
    }
  };

  if (loading) return <div className="profile-container"><p>Loading profile...</p></div>;
  if (!user) return <div className="profile-container"><p>Profile not found</p></div>;

  // Determine what to show based on permissions
  const showLimitedInfo = !isOwnProfile && !isFriend;
  const showFullProfile = isOwnProfile || isFriend;

  return (
    <div className="profile-container">
      {/* Profile Header */}
      <div className="profile-header">
        <div className="profile-info">
          <div className="profile-avatar">
            {user.avatar ? <img src={user.avatar} alt="Profile" style={{width: '100%', height: '100%', borderRadius: '50%'}} /> : '👤'}
          </div>
          <div className="profile-details">
            <h1>{user.name}</h1>
            
            {showLimitedInfo ? (
              <div>
                <p style={{color: '#95a5a6', fontStyle: 'italic'}}>
                  Connect as friends to view full profile
                </p>
                <button 
                  onClick={handleAddFriend}
                  className="nav-button"
                  style={{backgroundColor: '#27ae60', marginTop: '10px'}}
                >
                  Send Friend Request
                </button>
              </div>
            ) : (
              <div>
                <p>{user.bio || 'No bio yet'}</p>
                <p>Email: {user.email}</p>
                <p style={{fontSize: '14px', color: '#95a5a6', marginTop: '10px'}}>
                  Member since: {new Date(user.createdAt).toLocaleDateString()}
                </p>
                
                {/* Friend Management Buttons */}
                {!isOwnProfile && (
                  <div style={{marginTop: '15px'}}>
                    {isFriend ? (
                      <button 
                        onClick={handleRemoveFriend}
                        className="nav-button"
                        style={{backgroundColor: '#e74c3c'}}
                      >
                        Remove Friend
                      </button>
                    ) : (
                      <button 
                        onClick={handleAddFriend}
                        className="nav-button"
                        style={{backgroundColor: '#27ae60'}}
                      >
                        Add Friend
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Profile Section (only for own profile) */}
      {isOwnProfile && (
        <EditProfile 
          userId={profileId} 
          onProfileUpdate={handleProfileUpdate}
        />
      )}

      {/* Projects Section (only show if own profile or friends) */}
      {showFullProfile && (
        <div className="projects-section">
          <h2 className="section-title">
            {isOwnProfile ? 'My Projects' : `${user.name}'s Projects`}
          </h2>
          <ProjectList userId={profileId} />
        </div>
      )}

      {/* Friends Section (only show if own profile or friends) */}
      {showFullProfile && (
        <div className="projects-section">
          <h2 className="section-title">
            {isOwnProfile ? 'My Friends' : `${user.name}'s Friends`}
          </h2>
          <FriendsList 
            userId={profileId} 
            isOwnProfile={isOwnProfile}
            currentUserId={currentUserId}
          />
        </div>
      )}

      {/* Delete Profile Button (only for own profile) */}
      {isOwnProfile && (
        <div className="profile-header" style={{backgroundColor: '#fff5f5', border: '1px solid #fed7d7'}}>
          <h3 style={{color: '#9b2c2c', marginBottom: '10px'}}>Danger Zone</h3>
          <p style={{color: '#e53e3e', marginBottom: '15px'}}>
            Once you delete your profile, there is no going back. Please be certain.
          </p>
          <button 
            onClick={handleDelete}
            className="nav-button"
            style={{backgroundColor: '#e53e3c'}}
          >
            Delete My Profile
          </button>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;