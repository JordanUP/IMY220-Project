import React, { useState, useEffect } from 'react';

const EditProfile = ({ userId, onProfileUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    bio: '',
    avatar: ''
  });
  const [loading, setLoading] = useState(false);

  // Fetch current user data when component mounts or userId changes
  useEffect(() => {
    async function fetchUserData() {
      try {
        const response = await fetch(`/api/users/${userId}`);
        if (response.ok) {
          const userData = await response.json();
          setFormData({
            name: userData.name || '',
            email: userData.email || '',
            bio: userData.bio || '',
            avatar: userData.avatar || ''
          });
        }
      } catch (err) {
        console.error('Error fetching user data:', err);
      }
    }

    if (userId) {
      fetchUserData();
    }
  }, [userId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      const updatedUser = await response.json();
      
      // Update localStorage if name changed
      if (formData.name) {
        localStorage.setItem('userName', formData.name);
      }

      // Notify parent component about the update
      if (onProfileUpdate) {
        onProfileUpdate(updatedUser);
      }

      setIsEditing(false);
    } catch (err) {
      console.error('Error updating profile:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    // Reset form data to current user data
    async function resetForm() {
      try {
        const response = await fetch(`/api/users/${userId}`);
        if (response.ok) {
          const userData = await response.json();
          setFormData({
            name: userData.name || '',
            email: userData.email || '',
            bio: userData.bio || '',
            avatar: userData.avatar || ''
          });
        }
      } catch (err) {
        console.error('Error resetting form:', err);
      }
    }

    resetForm();
    setIsEditing(false);
  };

  if (!isEditing) {
    return (
      <div className="profile-header">
        <div className="flex justify-between items-center mb-4">
          <h2 className="section-title">Profile Information</h2>
          <button
            onClick={() => setIsEditing(true)}
            className="profile-edit-button"
          >
            Edit Profile
          </button>
        </div>
        
        <div style={{textAlign: 'left'}}>
          <div className="form-group">
            <strong>Name:</strong> {formData.name}
          </div>
          <div className="form-group">
            <strong>Email:</strong> {formData.email}
          </div>
          <div className="form-group">
            <strong>Bio:</strong> {formData.bio || 'No bio yet'}
          </div>
          {formData.avatar && (
            <div className="form-group">
              <strong>Avatar:</strong> 
              <img 
                src={formData.avatar} 
                alt="Profile" 
                style={{width: '80px', height: '80px', borderRadius: '50%', marginTop: '10px'}}
              />
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="profile-header">
      <h2 className="section-title">Edit Profile</h2>
      
      <form onSubmit={handleSubmit} style={{textAlign: 'left'}}>
        <div className="form-group">
          <label className="form-label">Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className="form-input"
            required
          />
        </div>

        <div className="form-group">
          <label className="form-label">Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className="form-input"
            required
          />
        </div>

        <div className="form-group">
          <label className="form-label">Bio:</label>
          <textarea
            name="bio"
            value={formData.bio}
            onChange={handleInputChange}
            rows="4"
            className="form-input"
            placeholder="Tell us about yourself..."
          />
        </div>

        <div className="form-group">
          <label className="form-label">Avatar URL:</label>
          <input
            type="url"
            name="avatar"
            value={formData.avatar}
            onChange={handleInputChange}
            className="form-input"
            placeholder="https://example.com/avatar.jpg"
          />
        </div>

        <div style={{display: 'flex', gap: '15px', marginTop: '20px'}}>
          <button
            type="submit"
            disabled={loading}
            className="form-button signup-button"
            style={{width: 'auto'}}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
          
          <button
            type="button"
            onClick={() => setIsEditing(false)}
            disabled={loading}
            className="form-button"
            style={{backgroundColor: '#95a5a6', width: 'auto'}}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditProfile;