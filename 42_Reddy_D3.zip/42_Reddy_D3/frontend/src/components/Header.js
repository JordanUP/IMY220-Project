import React from "react";
import { Link, useNavigate } from "react-router-dom";
import SearchBar from "./SearchInput";

const Header = () => {
  const navigate = useNavigate();
  const userId = localStorage.getItem('userId');
  const userName = localStorage.getItem('userName');

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <header className="header">
        <Link to="/home" className="logo">la BIBLIOTECHA</Link>

        <nav>
            <Link to="/home" className="nav-link">
              Home
            </Link>
            <Link to={`/profile/${userId}`} className="nav-link">
              Profile
            </Link>

            <SearchBar />

          <span style={{ color: '#740000ff' }}>Would you like to leave?</span>
          <button
            onClick={handleLogout}
            className="nav-button"
          >
            Logout
          </button>
      </nav>
    </header>
  );
};

export default Header;