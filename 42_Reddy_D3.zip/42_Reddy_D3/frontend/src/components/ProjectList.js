// Temporary fix for ProjectList.js - Use client-side filtering
import React, { useState, useEffect } from 'react';
import ProjectPreview from './ProjectPreview';

const ProjectList = ({ userId }) => {
  const [allProjects, setAllProjects] = useState([]);
  const [userProjects, setUserProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchAllProjects() {
      if (!userId || userId === 'undefined') {
        setLoading(false);
        return;
      }

      setLoading(true);
      setError('');
      
      try {
        // First, get all projects
        const res = await fetch('/api/projects');
        if (!res.ok) throw new Error('Failed to fetch projects');
        
        const allProjectsData = await res.json();
        setAllProjects(allProjectsData);
        
        // Filter on client side: projects where user is owner or member
        const filtered = allProjectsData.filter(project => {
          const isOwner = project.owner === userId;
          const isMember = project.members && project.members.includes(userId);
          return isOwner || isMember;
        });
        
        setUserProjects(filtered);
      } catch (err) {
        console.error('Project fetch error:', err);
        setError('Failed to load projects: ' + err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchAllProjects();
  }, [userId]);

  if (loading) return <p>Loading projects...</p>;
  if (error) return <p style={{color: '#e74c3c'}}>{error}</p>;

  return (
    <section>
      {userProjects.length === 0 ? (
        <p style={{color: '#95a5a6', textAlign: 'center', padding: '20px'}}>
          No projects found.
        </p>
      ) : (
        <div className="projects-grid">
          {userProjects.map(project => (
            <ProjectPreview key={project._id} project={project} />
          ))}
        </div>
      )}
    </section>
  );
};

export default ProjectList;