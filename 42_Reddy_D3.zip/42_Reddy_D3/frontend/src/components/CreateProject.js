import React, {useState} from "react";
import { useNavigate } from "react-router-dom";

const CreateProject = () => {// Component for creating a new project
    const [name, setName] = useState(''); // State for name (req)
    const [description, setDescription] = useState(''); // State for desc
    const [hashtags, setHashtags] = useState(''); // State for hashtags (comma-separated)
    const [type, setType] = useState(''); // State for type (e.g., 'web')
    const [loading, setLoading] = useState(false); // State for loading
    const [files, setFiles] = useState([]); // State for files array
    const navigate = useNavigate(); // Hook for redirect.

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        const userId = localStorage.getItem('userId');
        if (!userId) {
            navigate('/');
            return;
        }

        setLoading(true);

        try {
            // Prepare file data (just names for demo)
            const fileData = files.map(file => ({
            name: file.name,
            type: file.type,
            size: file.size
            }));

            const projectData = {
            name,
            description,
            hashtags: hashtags.split(',').map(tag => tag.trim()).filter(tag => tag),
            type,
            owner: userId,
            members: [userId],
            files: fileData // Store file info
            };

            console.log('Creating project:', projectData);

            const res = await fetch('/api/projects', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(projectData)
            });

            if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || 'Create failed');
            }

            const data = await res.json();
            navigate(`/projects/${data._id}`);
        } catch (err) {
            console.error('Create project error:', err);
        } finally {
            setLoading(false);
        }
    };

  return (
    <div className="global-container">
      <div className="profile-header">
        <h1 className="page-title">Create New Project</h1>
        
        <form onSubmit={handleSubmit} style={{ textAlign: 'left' }}>
          <div className="form-group">
            <label className="form-label">PROJECT NAME *</label>
            <input 
              type="text" 
              value={name} 
              onChange={(e) => setName(e.target.value)} 
              required 
              className="form-input"
              placeholder="Enter project name"
            />
          </div>

          <div className="form-group">
            <label className="form-label">DESCRIPTION</label>
            <textarea 
              value={description} 
              onChange={(e) => setDescription(e.target.value)} 
              className="form-input" 
              style={{height: '100px'}}
              placeholder="Describe your project..."
            />
          </div>

          <div className="form-group">
            <label className="form-label">TYPE</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="form-input"
              required
            >
              <option value="">Select project type</option>
              <option value="web-application">Web Application</option>
              <option value="mobile-app">Mobile App</option>
              <option value="desktop-app">Desktop Application</option>
              <option value="library">Library/Framework</option>
              <option value="api">API</option>
              <option value="plugin">Plugin/Extension</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">HASHTAGS (comma separated)</label>
            <input 
              type="text" 
              value={hashtags} 
              onChange={(e) => setHashtags(e.target.value)} 
              className="form-input"
              placeholder="javascript, react, nodejs"
            />
            <small style={{color: '#95a5a6'}}>Separate tags with commas</small>
          </div>

          <button 
            type="submit" 
            className="form-button signup-button"
            disabled={loading}
            style={{width: '100%', marginTop: '20px'}}
          >
            {loading ? 'Creating Project...' : 'Create Project'}
          </button>

          <button 
            type="button"
            onClick={() => navigate('/home')}
            className="form-button"
            style={{
              backgroundColor: '#95a5a6', 
              width: '100%', 
              marginTop: '10px'
            }}
          >
            Cancel
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateProject;