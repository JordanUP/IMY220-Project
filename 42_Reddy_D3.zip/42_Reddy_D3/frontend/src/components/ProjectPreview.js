import React from "react";
import { Link } from "react-router-dom";

const ProjectPreview = ({ project }) => {
    return (
        <div className="project-card">
            <h3 className="project-name">{project.name}</h3>
            <p className="project-meta">{project.description}</p>
            
            <div style={{marginTop: '10px'}}>
                <span style={{
                    padding: '2px 6px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    backgroundColor: project.status === 'checked-out' ? '#f200004e' : '#00ff5154',
                    color: project.status === 'checked-out' ? '#9b2c2c' : '#00723dff',
                    marginRight: '8px'
                }}>
                    {project.status}
                </span>
                
                {project.type && (
                    <span style={{
                        fontSize: '12px',
                        color: '#ff0000ff',
                        backgroundColor: '#ebf8ff',
                        padding: '2px 6px',
                        borderRadius: '4px'
                    }}>
                        {project.type}
                    </span>
                )}
            </div>
            
            {project.hashtags && project.hashtags.length > 0 && (
                <div style={{marginTop: '8px'}}>
                    {project.hashtags.map((tag, index) => (
                        <span 
                            key={index}
                            style={{
                                fontSize: '11px',
                                color: '#000000ff',
                                backgroundColor: '#edf2f7',
                                padding: '1px 4px',
                                borderRadius: '2px',
                                marginRight: '4px'
                            }}
                        >
                            #{tag}
                        </span>
                    ))}
                </div>
            )}
            
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '15px'}}>
                <span className="project-meta" style={{fontSize: '12px'}}>
                    Version: {project.version}
                </span>
                <Link 
                    to={`/projects/${project._id}`}
                    className="nav-button"
                    style={{padding: '5px 10px', fontSize: '14px'}}
                >
                    View Details
                </Link>
            </div>
        </div>
    );
};

export default ProjectPreview;