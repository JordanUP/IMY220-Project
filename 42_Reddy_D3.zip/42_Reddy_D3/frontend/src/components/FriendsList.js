import React, { useState, useEffect } from 'react';

const FriendsList = ({ userId, isOwnProfile, currentUserId }) => {
  const [friends, setFriends] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchData() {
      // Don't fetch if no user ID
      if (!userId || userId === 'undefined') {
        console.log('No user ID provided, skipping friends fetch');
        setLoading(false);
        return;
      }

      setLoading(true);
      setError('');
      
      try {
        console.log('Fetching friends for user:', userId);
        
        // Fetch user data to get friends list
        const userRes = await fetch(`/api/users/${userId}`);
        if (!userRes.ok) throw new Error('Failed to fetch user data');
        
        const userData = await userRes.json();
        const friendIds = userData.friends || [];
        
        console.log('Friend IDs:', friendIds);

        // Fetch details for each friend
        const friendDetails = await Promise.all(
          friendIds.map(async (friendId) => {
            const res = await fetch(`/api/users/${friendId}`);
            return res.ok ? res.json() : null;
          })
        );
        
        // Filter out any failed fetches
        const validFriends = friendDetails.filter(friend => friend !== null);
        setFriends(validFriends);

        // Only fetch all users if this is the current user's own profile
        if (isOwnProfile) {
          const allUsersRes = await fetch('/api/users');// Fetch all users
          if (allUsersRes.ok) {// If successful
            const allUsersData = await allUsersRes.json();// Get data
            // Filter out current user and existing friends
            const filteredUsers = allUsersData.filter(user => 
              user._id !== userId && // Exclude self
              !friendIds.includes(user._id)// Exclude existing friends
            );
            setAllUsers(filteredUsers);// Set state
          }
        }

      } catch (err) {
        console.error('Friends fetch error:', err);
        setError('Failed to load friends: ' + err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [userId, isOwnProfile]);

  const handleAddFriend = async (friendId) => {
    try {
      const res = await fetch(`/api/users/${userId}/friend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      
      if (res.ok) {
        // Refresh the friends list
        window.location.reload();
      } else {
        throw new Error('Failed to add friend');
      }
    } catch (err) {
      console.error('Add friend error:', err);
    }
  };

  const handleUnfriend = async (friendId) => {
    try {
      const res = await fetch(`/api/users/${userId}/unfriend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });

      const result = await res.json();
      
      if (res.ok) {
        // Refresh the friends list
        window.location.reload();
      } else {
        throw new Error('Failed to remove friend' || result.error);
      }
    } catch (err) {
      console.error('Unfriend error:', err);
    }
  };

  if (!userId || userId === 'undefined') {
    return <p>Log in to see your friends</p>;
  }

  if (loading) return <p>Loading friends...</p>;
  if (error) return <p className="text-red-500">{error}</p>;

 return (
    <div>
      {/* Current Friends */}
      <div>
        <h4 className="section-title">Your Friends ({friends.length})</h4>
        {friends.length === 0 ? (
          <p>No friends yet. Add some below!</p>
        ) : (
          <div className="projects-grid">
            {friends.map(friend => (
              <div key={friend._id} className="project-card">
                <div>
                  <span className="project-name">{friend.name}</span>
                  <p className="project-meta">{friend.email}</p>
                </div>
                {/* Only show unfriend button if viewing own profile */}
                {isOwnProfile && (
                  <button 
                    onClick={() => handleUnfriend(friend._id)}
                    className="nav-button"
                    style={{backgroundColor: '#e74c3c', marginTop: '10px'}}
                  >
                    Unfriend
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Friends Section - Only show on own profile */}
      {isOwnProfile && (
        <div>
          <h4 className="section-title">Add Friends</h4>
          {allUsers.length === 0 ? (
            <p>No other users to add as friends.</p>
          ) : (
            <div className="projects-grid">
              {allUsers.map(user => (
                <div key={user._id} className="project-card">
                  <div>
                    <span className="project-name">{user.name}</span>
                    <p className="project-meta">{user.email}</p>
                  </div>
                  <button 
                    onClick={() => handleAddFriend(user._id)}
                    className="nav-button"
                    style={{backgroundColor: '#27ae60', marginTop: '10px'}}
                  >
                    Add Friend
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FriendsList;