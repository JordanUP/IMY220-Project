import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const LoginForm = () => { // Login form component
    const [email, setEmail] = useState("");// State for email input
    const [password, setPassword] = useState("");// State for password input
    const [error, setError] = useState(null);// State for error messages
    const navigate = useNavigate();// Hook for navigation

    const handleSubmit = async (e) => {// Handle form submission asynchronously
        e.preventDefault();// Prevent default form submission (reloading the page)
        setError("");// Clear previous errors

        if (!email.includes("@") || password.length < 8) {// Basic validation
            setError("Please enter a valid email and a password with at least 8 characters.");
            return;
        }

        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });
            
            const data = await res.json();
            
            if (res.ok) {
                localStorage.setItem('userId', data._id);
                localStorage.setItem('userName', data.name);
                localStorage.setItem('userEmail', data.email);
                console.log('Login successful, user ID:', data._id);
                navigate('/home');
            } else {
                setError(data.error || 'Login failed');
            }
        } catch (err) {
            console.error('Fetch error:', err);
            setError('Login failed: ' + err.message);
        }
    };

    return (
        <div className="form-container">
            
            <h2 className="form-title">Welcome Back</h2>
            
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="email" className="form-label">EMAIL</label>
                    <input 
                        id="email"
                        type="email" 
                        placeholder="Email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        required 
                        className="form-input"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="pass" className="form-label">PASSWORD</label>
                    <input 
                        id="pass"
                        type="password" 
                        placeholder="Password" 
                        value={password} 
                        onChange={(e) => setPassword(e.target.value)} 
                        minLength={8} 
                        required 
                        className="form-input"
                    />
                </div>
                {error && <p style={{color: 'red', marginBottom: '15px'}}>{error}</p>}
                <button type="submit" className="form-button login-button">Login</button>
            </form>
        </div>
    );
};

export default LoginForm;