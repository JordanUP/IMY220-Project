import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const SignupForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [repeatPassword, setRepeatPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.includes('@') || password.length < 8 || password !== repeatPassword) {
      return;
    }
    fetch('/api/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    })
      .then(res => {
    if (!res.ok) {
      return res.text().then(text => { throw new Error(text); });  // Get text if not JSON
    }
    return res.json();
  })
  .then(data => {
    localStorage.setItem('userId', data._id);// Store userId in local storage
    navigate('/home');  // Redirect to home page
  })
  .catch(err => {
    console.error('Fetch error:', err);
  });
  };

   return (
    <div className="form-container">
      
      <h2 className="form-title">Let's get started</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name" className="form-label">NAME</label>
          <input 
            id="name"
            type="text" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
            required 
            placeholder="Name"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="email" className="form-label">EMAIL</label>
          <input 
            id="email"
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required 
            placeholder="Email"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="pass" className="form-label">PASSWORD</label>
          <input 
            id="pass"
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            minLength={8} 
            required 
            placeholder="Password"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="repeat-pass" className="form-label">REPEAT PASSWORD</label>
          <input 
            id="repeat-pass"
            type="password" 
            value={repeatPassword} 
            onChange={(e) => setRepeatPassword(e.target.value)} 
            minLength={8} 
            required 
            placeholder="Repeat Password"
            className="form-input"
          />
        </div>
        <button type="submit" className="form-button signup-button">Sign Up</button>
      </form>
    </div>
  );
};

export default SignupForm;