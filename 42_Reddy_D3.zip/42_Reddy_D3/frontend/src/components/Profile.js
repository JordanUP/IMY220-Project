import React from 'react'; // React

const Profile = ({ user }) => ( // Component for displaying profile
<div className="profile-header">
    <div className="profile-info">
      <div className="profile-avatar">
        {user.avatar ? <img src={user.avatar} alt="Avatar" style={{width: '100%', height: '100%', borderRadius: '50%'}} /> : '👤'}
      </div>
      <div className="profile-details">
        <h1>{user.name}</h1>
        <p>{user.bio}</p>
      </div>
    </div>
  </div>
);

export default Profile; // Export for Profile page.