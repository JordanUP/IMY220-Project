import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const SearchInput = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState({ users: [], projects: [] });
  const [showResults, setShowResults] = useState(false);
  const [currentUserFriends, setCurrentUserFriends] = useState([]);
  const [currentUserId, setCurrentUserId] = useState(null);
  const navigate = useNavigate();

  // Fetch current user's friends when component mounts
  useEffect(() => {
    const userId = localStorage.getItem('userId');
    if (userId && userId !== 'undefined') {
      setCurrentUserId(userId);
      fetchCurrentUserFriends(userId);
    }
  }, []);

  const fetchCurrentUserFriends = async (userId) => {
    try {
      const response = await fetch(`/api/users/${userId}`);
      if (response.ok) {
        const userData = await response.json();
        setCurrentUserFriends(userData.friends || []);
      }
    } catch (err) {
      console.error('Failed to fetch user friends:', err);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) { return; }

    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json();
      setResults(data);
      setShowResults(true);
    } catch (err) {
      console.log('Search error:', err);
    }
  };

  const handleAddFriend = async (friendId) => {
    if (!currentUserId) {
      console.error('Add friend error: User not logged in');
      return;
    }

    try {
      const response = await fetch(`/api/users/${currentUserId}/friend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      
      if (!response.ok) throw new Error('Failed to send friend request');

      console.log('Friend request sent successfully');
      // Update friends list
      fetchCurrentUserFriends(currentUserId);
      setShowResults(false);
    } catch (err) {
      console.error('Add friend error:', err);
    }
  };

  const handleRemoveFriend = async (friendId) => {
    if (!currentUserId) {
      console.error('Remove friend error: User not logged in');
      return;
    }

    try {
      const response = await fetch(`/api/users/${currentUserId}/unfriend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId })
      });
      
      if (!response.ok) throw new Error('Failed to remove friend');

      // Update friends list
      fetchCurrentUserFriends(currentUserId);
      setShowResults(false);
    } catch (err) {
      console.error('Remove friend error:', err);
    }
  };

  // Check if a user is already a friend
  const isUserFriend = (userId) => {
    return currentUserFriends.some(friendId => {
      const friendIdStr = friendId.toString ? friendId.toString() : friendId;
      const userIdStr = userId.toString ? userId.toString() : userId;
      return friendIdStr === userIdStr;
    });
  };

  return (
    <div style={{ position: 'relative' }}>
      <form onSubmit={handleSearch} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search users or projects..."
          className="form-input"
          style={{ width: '300px', margin: 0 }}
        />
        <button type="submit" className="nav-button" style={{ margin: 0 }}>
          Search
        </button>
      </form>

      {showResults && (
        <div style={{
          position: 'absolute',
          top: '100%',
          left: 0,
          right: 0,
          backgroundColor: 'white',
          border: '1px solid #ddd',
          borderRadius: '4px',
          padding: '15px',
          zIndex: 1000,
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
          maxHeight: '400px',
          overflowY: 'auto'
        }}>
          <button 
            onClick={() => setShowResults(false)}
            style={{ float: 'right', background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer' }}
          >
            ×
          </button>

          <h4>Users ({results.users.length})</h4>
          {results.users.length === 0 ? (
            <p style={{ color: '#95a5a6' }}>No users found</p>
          ) : (
            results.users.map(user => {
              const isCurrentUser = currentUserId === user._id;
              const isFriend = isUserFriend(user._id);
              
              return (
                <div key={user._id} style={{ padding: '8px', borderBottom: '1px solid #eee' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ flex: 1 }}>
                      <span 
                        onClick={() => navigate(`/profile/${user._id}`)}
                        style={{ 
                          cursor: 'pointer', 
                          color: '#3498db', 
                          fontWeight: '500',
                          display: 'block',
                          marginBottom: '5px'
                        }}
                      >
                        {user.name} ({user.email})
                      </span>
                      {isFriend && (
                        <span style={{ 
                          fontSize: '12px', 
                          color: '#27ae60', 
                          fontWeight: 'bold' 
                        }}>
                          ✓ Friends
                        </span>
                      )}
                    </div>
                    {!isCurrentUser && (
                      <div>
                        {isFriend ? (
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveFriend(user._id);
                            }}
                            className="nav-button"
                            style={{ 
                              backgroundColor: '#e74c3c', 
                              padding: '4px 8px', 
                              fontSize: '12px',
                              margin: 0
                            }}
                          >
                            Unfriend
                          </button>
                        ) : (
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAddFriend(user._id);
                            }}
                            className="nav-button"
                            style={{ 
                              backgroundColor: '#27ae60', 
                              padding: '4px 8px', 
                              fontSize: '12px',
                              margin: 0
                            }}
                          >
                            Add Friend
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}

          <h4 style={{ marginTop: '15px' }}>Projects ({results.projects.length})</h4>
          {results.projects.length === 0 ? (
            <p style={{ color: '#95a5a6' }}>No projects found</p>
          ) : (
            results.projects.map(project => (
              <div key={project._id} style={{ padding: '8px', borderBottom: '1px solid #eee' }}>
                <span 
                  onClick={() => navigate(`/projects/${project._id}`)}
                  style={{ cursor: 'pointer', color: '#3498db' }}
                >
                  {project.name} - {project.type}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default SearchInput;